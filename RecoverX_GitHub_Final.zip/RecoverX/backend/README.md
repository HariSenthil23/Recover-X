# RecoverX Backend — Final Buildathon Backend

A buildathon-ready backend contract for the sealed RecoverX UI.

## What it provides

- Demo authentication with JWT
- Command Center KPIs
- Live payment operations feed
- Incidents + incident timeline
- Predictive alerts
- Root-cause investigation results
- Recovery queue
- Counterfactual simulations
- Provider health
- Routing recommendations
- Human-in-the-loop approvals
- AI agent operations
- Revenue analytics + attribution
- Transaction explorer + transaction timeline
- Audit log
- Decision replay
- WebSocket live event stream
- Safe demo execution: no real money movement and no real provider calls

## Run

```bash
npm install
copy .env.example .env
npm run dev
```

Mac/Linux:

```bash
cp .env.example .env
npm install
npm run dev
```

Backend:
`http://localhost:4000`

Health:
`GET /api/health`

Swagger/OpenAPI is intentionally not required for the prototype; the complete endpoint contract is in `docs/API.md`.

## Demo login

Use any email and password of 6+ characters. The backend creates a demo operator token.

Example:

```json
POST /api/auth/login
{
  "email": "operator@recoverx.demo",
  "password": "recoverx"
}
```

Then send:

`Authorization: Bearer <token>`

## WebSocket

Connect to:

`ws://localhost:4000/ws?token=<JWT>`

The server emits `payment_event`, `incident_update`, `agent_activity`, `simulation_update`, `approval_update`, and `kpi_update`.

## Safety boundary

All financial actions are simulation-only. `POST /api/recovery/actions/:id/execute` creates an execution record and audit event but never moves money, contacts a bank/PSP, or changes live traffic.

For a real integration, replace the demo provider adapter and add production authentication, secrets management, idempotency, signed webhooks, durable DB/queue, RBAC and approval policies.
