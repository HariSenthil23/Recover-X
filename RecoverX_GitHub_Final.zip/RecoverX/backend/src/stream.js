import { randomUUID } from "node:crypto";
import { db, persist } from "./store.js";

const state = { broadcast: () => {} };
export const emitEvent = {
  setBroadcaster(fn) { state.broadcast = fn; },
  send(type, data) { state.broadcast({ type, data }); }
};

export function startDemoStream() {
  setInterval(() => {
    const rails = ["UPI", "CARDS", "NET_BANKING"];
    const rail = rails[Math.floor(Math.random() * rails.length)];
    const provider = rail === "NET_BANKING" ? db.providers[2] : db.providers[Math.floor(Math.random() * 2)];
    const statuses = ["SUCCESS", "SUCCESS", "SUCCESS", "RECOVERED", "FAILED", "RETRYING"];
    const status = statuses[Math.floor(Math.random() * statuses.length)];
    const amount = [499, 1299, 2499, 7999, 12450, 25000][Math.floor(Math.random() * 6)];

    const event = {
      id: randomUUID(),
      transactionId: `RX-${Math.random().toString(16).slice(2, 8).toUpperCase()}`,
      timestamp: new Date().toISOString(),
      rail,
      provider: provider.name,
      amount,
      currency: "INR",
      status,
      failureReason: status === "FAILED" ? "provider_timeout" : null,
      recoveryStatus: status === "RECOVERED" ? "RECOVERED" : status === "RETRYING" ? "IN_PROGRESS" : "NONE"
    };

    db.agentActivity.push({
      id: randomUUID(),
      timestamp: event.timestamp,
      agent: "Payment Monitoring Agent",
      event: `${rail} payment event ${status.toLowerCase()}`,
      severity: status === "FAILED" ? "WARN" : "INFO"
    });
    db.agentActivity = db.agentActivity.slice(-100);
    persist();

    emitEvent.send("payment_event", event);
    emitEvent.send("agent_activity", db.agentActivity.at(-1));
    emitEvent.send("kpi_update", {
      transactionsMonitored: 1248392 + Math.floor(Math.random() * 200),
      predictedFailures: 18492 + Math.floor(Math.random() * 40),
      recoverySuccess: 0.946 + (Math.random() * 0.002 - 0.001),
      revenueProtected: 28400000 + Math.floor(Math.random() * 30000)
    });
  }, 2500);
}
