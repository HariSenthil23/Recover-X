import { seedIfEmpty } from "./store.js";
seedIfEmpty();
console.log("RecoverX demo data seeded.");
