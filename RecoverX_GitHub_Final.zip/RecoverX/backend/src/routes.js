import { Router } from "express";
import { randomUUID } from "node:crypto";
import { z } from "zod";
import { db, persist, reseed } from "./store.js";
import { emitEvent } from "./stream.js";

export const routes = Router();

const now = () => new Date().toISOString();
const audit = (actor, action, resource, outcome, details) => {
  db.auditLog.unshift({ id: randomUUID(), timestamp: now(), actor, actorType: actor.startsWith("agent_") ? "AGENT" : "OPERATOR", action, resource, outcome, details });
  db.auditLog = db.auditLog.slice(0, 500);
  persist();
};

routes.get("/dashboard/summary", (_req, res) => res.json({
  generatedAt: now(),
  simulated: true,
  kpis: {
    transactionsMonitored: 1248392,
    predictedFailures: 18492,
    recoverySuccess: 0.946,
    revenueProtected: 28400000,
    averageRecoveryLatencyMs: 420,
    revenueAtRisk: 4280000,
    expectedRecovery: 3160000,
    recoveredRevenue: 3160000,
    activeIncidents: db.incidents.filter(i => i.status !== "RESOLVED").length,
    providerHealth: Math.round(db.providers.reduce((a,p) => a + p.healthScore, 0) / db.providers.length)
  },
  comparison: { period: "previous_24h", transactions: 0.084, predictedFailures: -0.127, recoverySuccess: 0.042, revenueProtected: 3840000, latencyMs: -18 }
}));

routes.get("/dashboard/payment-health", (_req, res) => res.json(db.providers.map(p => ({
  rail: p.name.includes("ICICI") ? "NET BANKING" : p.name.includes("Axis") ? "CARDS" : "UPI",
  providerId: p.id,
  provider: p.name,
  status: p.status,
  successRate: p.successRate,
  latencyMs: p.latencyMs,
  sparkline: Array.from({length: 18}, (_,i) => Math.max(80, Math.round(p.successRate - (p.status === "DEGRADED" ? i % 5 : i % 2) + Math.sin(i)*0.3)))
}))));

routes.get("/dashboard/live-operations", (req, res) => {
  const limit = Math.min(Number(req.query.limit || 50), 200);
  res.json(db.transactions.slice(0, limit));
});

routes.get("/transactions", (req, res) => {
  let data = [...db.transactions];
  for (const key of ["status", "rail", "provider"]) if (req.query[key]) data = data.filter(x => String(x[key]).toLowerCase() === String(req.query[key]).toLowerCase());
  res.json(data.slice(0, Math.min(Number(req.query.limit || 100), 500)));
});
routes.get("/transactions/:id", (req, res) => {
  const item = db.transactions.find(x => x.id === req.params.id);
  if (!item) return res.status(404).json({ error: "NOT_FOUND" });
  res.json(item);
});
routes.get("/transactions/:id/timeline", (req, res) => {
  const item = db.transactions.find(x => x.id === req.params.id);
  if (!item) return res.status(404).json({ error: "NOT_FOUND" });
  res.json(db.decisionReplay.find(x => x.transactionId === item.id)?.events || []);
});

routes.get("/incidents", (req, res) => {
  let data = [...db.incidents];
  if (req.query.status) data = data.filter(x => x.status === req.query.status);
  if (req.query.severity) data = data.filter(x => x.severity === req.query.severity);
  res.json(data);
});
routes.get("/incidents/:id", (req, res) => {
  const incident = db.incidents.find(x => x.id === req.params.id);
  if (!incident) return res.status(404).json({ error: "NOT_FOUND" });
  res.json({ ...incident, evidence: ["failure rate +18%", "authorization latency +31%", "issuer timeout spike", "affected transaction cohort detected"], strategies: [
    { id: "retry", name: "Retry", successProbability: 0.31, expectedRecovery: 458000, risk: "MEDIUM", latencyImpactMs: 80, duplicateRisk: "LOW" },
    { id: "reroute", name: "Reroute", successProbability: 0.74, expectedRecovery: 1095200, risk: "LOW", latencyImpactMs: -220, duplicateRisk: "LOW" },
    { id: "redistribute", name: "Traffic redistribution", successProbability: 0.82, expectedRecovery: 1210000, risk: "MEDIUM", latencyImpactMs: -310, duplicateRisk: "LOW" }
  ]});
});
routes.get("/incidents/:id/timeline", (req, res) => {
  const incident = db.incidents.find(x => x.id === req.params.id);
  if (!incident) return res.status(404).json({ error: "NOT_FOUND" });
  res.json([
    ["Payment failures detected", "system", incident.detectedAt],
    ["Prediction generated", "agent_anomaly", new Date(new Date(incident.detectedAt).getTime()+700).toISOString()],
    ["Anomaly detected", "agent_anomaly", new Date(new Date(incident.detectedAt).getTime()+1400).toISOString()],
    ["Incident created", "system", new Date(new Date(incident.detectedAt).getTime()+2100).toISOString()],
    ["Root cause investigated", "agent_rootcause", new Date(new Date(incident.detectedAt).getTime()+2800).toISOString()],
    ["Strategies simulated", "agent_recovery", new Date(new Date(incident.detectedAt).getTime()+3500).toISOString()],
    ["Risk evaluated", "agent_risk", new Date(new Date(incident.detectedAt).getTime()+4200).toISOString()],
    ["Approval requested", "system", new Date(new Date(incident.detectedAt).getTime()+4900).toISOString()]
  ].map(([event, actor, timestamp]) => ({ event, actor, timestamp, status: "COMPLETED" })));
});
routes.post("/incidents/:id/investigate", (req, res) => {
  const incident = db.incidents.find(x => x.id === req.params.id);
  if (!incident) return res.status(404).json({ error: "NOT_FOUND" });
  incident.status = "INVESTIGATING";
  incident.rootCause = "Elevated issuer timeout rate";
  incident.aiConfidence = 0.947;
  audit("agent_rootcause", "ROOT_CAUSE_INVESTIGATION", incident.id, "SUCCESS", incident.rootCause);
  emitEvent.send("incident_update", incident);
  res.json({ incident, investigation: { rootCause: incident.rootCause, confidence: incident.aiConfidence, evidence: ["authorization latency +31%", "decline rate +18%", "issuer timeout spike", "affected cohort detected"] }});
});
routes.post("/incidents/:id/simulate", (req, res) => {
  const incident = db.incidents.find(x => x.id === req.params.id);
  if (!incident) return res.status(404).json({ error: "NOT_FOUND" });
  const simulation = createSimulation(incident.id, req.body?.strategy);
  res.status(201).json(simulation);
});

routes.get("/predictions", (_req, res) => res.json(db.predictions));
routes.get("/predictions/:id", (req, res) => {
  const item = db.predictions.find(x => x.id === req.params.id);
  if (!item) return res.status(404).json({ error: "NOT_FOUND" });
  res.json(item);
});

routes.get("/recovery/queue", (_req, res) => res.json(db.recoveryQueue));
routes.post("/recovery/queue/:id/simulate", (req, res) => {
  const item = db.recoveryQueue.find(x => x.id === req.params.id);
  if (!item) return res.status(404).json({ error: "NOT_FOUND" });
  res.json(createSimulation(null, req.body?.strategy || item.recommendedAction, item));
});
routes.post("/recovery/queue/:id/execute", (req, res) => {
  const item = db.recoveryQueue.find(x => x.id === req.params.id);
  if (!item) return res.status(404).json({ error: "NOT_FOUND" });
  if (item.requiresApproval && !db.approvals.some(a => a.status === "APPROVED" && a.action.includes(item.recommendedAction))) {
    return res.status(409).json({ error: "APPROVAL_REQUIRED", message: "Human approval is required before this simulated action can execute." });
  }
  item.status = "EXECUTED_DEMO";
  audit("operator", "RECOVERY_EXECUTE_SIMULATION", item.id, "SUCCESS", "No live transaction or financial rail was affected.");
  emitEvent.send("approval_update", item);
  res.json({ executed: true, simulated: true, item });
});

function createSimulation(incidentId, selectedStrategy, queueItem) {
  const id = `SIM-${Date.now().toString(36).toUpperCase()}`;
  const strategies = [
    { id: "retry", name: "Retry same route", successProbability: 0.31, expectedRecovery: 458000, risk: "MEDIUM", latencyImpactMs: 80, attemptCount: 2, duplicateRisk: "LOW", expectedValue: 458000 },
    { id: "reroute", name: "Alternate route", successProbability: 0.74, expectedRecovery: 1095200, risk: "LOW", latencyImpactMs: -220, attemptCount: 1, duplicateRisk: "LOW", expectedValue: 1095200 },
    { id: "redistribute", name: "Traffic redistribution", successProbability: 0.82, expectedRecovery: 1210000, risk: "MEDIUM", latencyImpactMs: -310, attemptCount: 1, duplicateRisk: "LOW", expectedValue: 1210000 }
  ];
  const chosen = selectedStrategy ? strategies.find(s => s.id === selectedStrategy.toLowerCase() || s.name.toLowerCase().includes(String(selectedStrategy).toLowerCase())) : strategies[1];
  const sim = {
    id, incidentId, transactionId: queueItem?.transactionId || null, status: "COMPLETED",
    safety: "SIMULATION — NO LIVE TRANSACTIONS AFFECTED",
    startedAt: now(), completedAt: now(),
    currentState: { failureRate: 0.078, latencyMs: 1240, affectedVolumePerHour: 1820000 },
    strategies, recommendedStrategy: chosen || strategies[1],
    events: ["Building transaction cohort...", "Replaying failure pattern...", "Testing routing policy...", "Calculating expected recovery..."].map((message, i) => ({ message, atMs: i * 350 })),
    modelOutput: { expectedRecovery: (chosen || strategies[1]).expectedRecovery, confidence: 0.91 }
  };
  db.simulations.unshift(sim);
  db.simulations = db.simulations.slice(0, 100);
  audit("agent_recovery", "SIMULATION_RUN", id, "SUCCESS", sim.safety);
  emitEvent.send("simulation_update", sim);
  persist();
  return sim;
}
routes.post("/simulations", (req, res) => {
  const parsed = z.object({ incidentId: z.string().optional(), strategy: z.string().optional(), transactionId: z.string().optional() }).safeParse(req.body || {});
  if (!parsed.success) return res.status(400).json({ error: "VALIDATION_ERROR" });
  res.status(201).json(createSimulation(parsed.data.incidentId, parsed.data.strategy, parsed.data.transactionId ? db.recoveryQueue.find(x => x.transactionId === parsed.data.transactionId) : undefined));
});
routes.get("/simulations/:id", (req, res) => {
  const item = db.simulations.find(x => x.id === req.params.id);
  if (!item) return res.status(404).json({ error: "NOT_FOUND" });
  res.json(item);
});
routes.get("/simulations/:id/events", (req, res) => {
  const item = db.simulations.find(x => x.id === req.params.id);
  if (!item) return res.status(404).json({ error: "NOT_FOUND" });
  res.json(item.events);
});

routes.get("/providers", (_req, res) => res.json(db.providers));
routes.get("/providers/:id", (req, res) => {
  const p = db.providers.find(x => x.id === req.params.id);
  if (!p) return res.status(404).json({ error: "NOT_FOUND" });
  res.json({ ...p, telemetry: Array.from({length: 24}, (_,i) => ({ t: i, successRate: Math.max(80, p.successRate - (p.status === "DEGRADED" ? i % 5 : i % 2)), latencyMs: p.latencyMs + (i % 4) * 13 })) });
});

routes.get("/routing", (_req, res) => res.json(db.routing));
routes.post("/routing/recommendations/:id/approve", (req, res) => {
  const r = db.routing.find(x => x.id === req.params.id);
  if (!r) return res.status(404).json({ error: "NOT_FOUND" });
  r.policyStatus = "APPROVED";
  r.executionStatus = "APPROVED_NOT_EXECUTED";
  audit("operator", "ROUTING_RECOMMENDATION_APPROVED", r.id, "SUCCESS", "Approval recorded; no live routing changed.");
  emitEvent.send("approval_update", r);
  res.json(r);
});
routes.post("/routing/recommendations/:id/reject", (req, res) => {
  const r = db.routing.find(x => x.id === req.params.id);
  if (!r) return res.status(404).json({ error: "NOT_FOUND" });
  r.policyStatus = "REJECTED";
  r.executionStatus = "NOT_EXECUTED";
  audit("operator", "ROUTING_RECOMMENDATION_REJECTED", r.id, "SUCCESS", req.body?.reason || "Rejected by operator.");
  res.json(r);
});

routes.get("/approvals", (_req, res) => res.json(db.approvals));
routes.get("/approvals/:id", (req, res) => {
  const a = db.approvals.find(x => x.id === req.params.id);
  if (!a) return res.status(404).json({ error: "NOT_FOUND" });
  res.json(a);
});
routes.post("/approvals/:id/approve", (req, res) => {
  const a = db.approvals.find(x => x.id === req.params.id);
  if (!a) return res.status(404).json({ error: "NOT_FOUND" });
  a.status = "APPROVED"; a.decidedAt = now(); a.decidedBy = req.user.email;
  audit("operator", "APPROVAL_GRANTED", a.id, "SUCCESS", a.action);
  emitEvent.send("approval_update", a);
  res.json(a);
});
routes.post("/approvals/:id/reject", (req, res) => {
  const a = db.approvals.find(x => x.id === req.params.id);
  if (!a) return res.status(404).json({ error: "NOT_FOUND" });
  const reason = String(req.body?.reason || "").trim();
  if (!reason) return res.status(400).json({ error: "VALIDATION_ERROR", message: "Rejection reason required." });
  a.status = "REJECTED"; a.decidedAt = now(); a.decidedBy = req.user.email; a.rejectionReason = reason;
  audit("operator", "APPROVAL_REJECTED", a.id, "SUCCESS", reason);
  emitEvent.send("approval_update", a);
  res.json(a);
});

routes.get("/agents", (_req, res) => res.json(db.agents));
routes.get("/agents/activity", (req, res) => res.json(db.agentActivity.slice(0, Math.min(Number(req.query.limit || 50), 200))));
routes.get("/agents/:id", (req, res) => {
  const a = db.agents.find(x => x.id === req.params.id);
  if (!a) return res.status(404).json({ error: "NOT_FOUND" });
  res.json({ ...a, recentActivity: db.agentActivity.filter(x => x.agent.toLowerCase().includes(a.name.split(" Agent")[0].toLowerCase())).slice(0, 20) });
});

routes.get("/revenue/summary", (_req, res) => res.json({ ...db.revenue.summary, distinction: { recoveredRevenue: "Value successfully recovered after a payment failure.", protectedRevenue: "Value protected through successful payment reliability interventions." }, dataAvailability: { recoveryCost: db.revenue.summary.recoveryCost === null ? "COST DATA UNAVAILABLE" : "AVAILABLE", roi: db.revenue.summary.roi === null ? "ROI UNAVAILABLE" : "AVAILABLE" } }));
routes.get("/revenue/series", (req, res) => {
  const range = String(req.query.range || "24H").toUpperCase();
  res.json(range === "7D" ? db.revenue.series7D : range === "30D" ? db.revenue.series30D : db.revenue.series24H);
});
routes.get("/revenue/attribution", (_req, res) => res.json(db.revenue.attribution));

// Demo-only: restores the seeded dataset so the buildathon flow can be replayed.
// Disabled automatically when DEMO_MODE=false so it can never touch production data.
routes.post("/demo/reset", (req, res) => {
  if (process.env.DEMO_MODE === "false") {
    return res.status(403).json({ error: "FORBIDDEN", message: "Demo reset is disabled outside demo mode." });
  }
  reseed();
  audit("operator", "DEMO_RESET", "recoverx", "SUCCESS", "Demo dataset restored to initial seeded state.");
  emitEvent.send("kpi_update", { reset: true });
  res.json({ reset: true, timestamp: now() });
});

routes.get("/audit-log", (req, res) => res.json(db.auditLog.slice(0, Math.min(Number(req.query.limit || 100), 500))));
routes.get("/decision-replay/:transactionId", (req, res) => {
  const item = db.decisionReplay.find(x => x.transactionId === req.params.transactionId);
  if (!item) return res.status(404).json({ error: "NOT_FOUND" });
  res.json(item);
});
