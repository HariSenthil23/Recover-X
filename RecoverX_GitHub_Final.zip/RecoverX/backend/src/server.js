import "dotenv/config";
import http from "node:http";
import express from "express";
import cors from "cors";
import jwt from "jsonwebtoken";
import { WebSocketServer } from "ws";
import { URL } from "node:url";
import { db, seedIfEmpty, persist } from "./store.js";
import { emitEvent, startDemoStream } from "./stream.js";
import { routes } from "./routes.js";

const app = express();
const server = http.createServer(app);

const PORT = Number(process.env.PORT || 4000);
const JWT_SECRET = process.env.JWT_SECRET || "recoverx-demo-secret";
const FRONTEND_ORIGIN = process.env.FRONTEND_ORIGIN || "http://localhost:5173";

app.use(cors({
  origin: FRONTEND_ORIGIN === "*" ? true : FRONTEND_ORIGIN,
  credentials: true
}));
app.use(express.json({ limit: "1mb" }));

app.get("/api/health", (_req, res) => {
  res.json({
    ok: true,
    service: "recoverx-api",
    mode: process.env.DEMO_MODE === "false" ? "integration" : "demo",
    timestamp: new Date().toISOString(),
    version: "1.0.0"
  });
});

app.post("/api/auth/login", (req, res) => {
  const email = String(req.body?.email || "").trim().toLowerCase();
  const password = String(req.body?.password || "");
  if (!email || !email.includes("@") || password.length < 6) {
    return res.status(400).json({ error: "VALIDATION_ERROR", message: "Valid email and 6+ character password required." });
  }

  let user = db.users.find(u => u.email === email);
  if (!user) {
    user = {
      id: "usr_demo_operator",
      email,
      name: "Demo Operator",
      role: "OPERATIONS_ADMIN",
      environment: "DEMO"
    };
    db.users.push(user);
    persist();
  }

  const token = jwt.sign({ sub: user.id, email: user.email, role: user.role }, JWT_SECRET, { expiresIn: "12h" });
  res.json({ token, user });
});

function auth(req, res, next) {
  const header = req.headers.authorization || "";
  const token = header.startsWith("Bearer ") ? header.slice(7) : "";
  if (!token) return res.status(401).json({ error: "UNAUTHORIZED", message: "Bearer token required." });

  try {
    req.user = jwt.verify(token, JWT_SECRET);
    next();
  } catch {
    return res.status(401).json({ error: "UNAUTHORIZED", message: "Token invalid or expired." });
  }
}

app.get("/api/auth/me", auth, (req, res) => {
  const user = db.users.find(u => u.id === req.user.sub);
  res.json({ user: user || null });
});

app.use("/api", auth, routes);

app.use((err, _req, res, _next) => {
  console.error(err);
  res.status(500).json({ error: "INTERNAL_ERROR", message: "Unexpected server error." });
});

seedIfEmpty();

const wss = new WebSocketServer({ noServer: true });
server.on("upgrade", (request, socket, head) => {
  const url = new URL(request.url, `http://${request.headers.host}`);
  if (url.pathname !== "/ws") {
    socket.destroy();
    return;
  }
  try {
    jwt.verify(url.searchParams.get("token") || "", JWT_SECRET);
    wss.handleUpgrade(request, socket, head, ws => {
      ws.isAlive = true;
      ws.on("pong", () => { ws.isAlive = true; });
      wss.emit("connection", ws);
    });
  } catch {
    socket.write("HTTP/1.1 401 Unauthorized\r\n\r\n");
    socket.destroy();
  }
});

wss.on("connection", ws => {
  ws.send(JSON.stringify({ type: "connected", data: { service: "recoverx", mode: "DEMO" }, ts: new Date().toISOString() }));
});

const broadcast = payload => {
  const msg = JSON.stringify({ ...payload, ts: new Date().toISOString() });
  for (const client of wss.clients) {
    if (client.readyState === 1) client.send(msg);
  }
};

emitEvent.setBroadcaster(broadcast);
setInterval(() => {
  for (const ws of wss.clients) {
    if (!ws.isAlive) return ws.terminate();
    ws.isAlive = false;
    ws.ping();
  }
}, 30000);

startDemoStream();
server.listen(PORT, () => {
  console.log(`RecoverX API running on http://localhost:${PORT}`);
  console.log(`WebSocket running on ws://localhost:${PORT}/ws?token=<JWT>`);
});
