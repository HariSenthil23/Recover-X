import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { randomUUID } from "node:crypto";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const dataDir = path.join(__dirname, "..", "data");
const dataFile = path.join(dataDir, "recoverx.json");

const blank = () => ({
  users: [],
  transactions: [],
  incidents: [],
  predictions: [],
  recoveryQueue: [],
  simulations: [],
  providers: [],
  routing: [],
  approvals: [],
  agents: [],
  agentActivity: [],
  revenue: {
    summary: {},
    series24H: [],
    series7D: [],
    series30D: [],
    attribution: []
  },
  auditLog: [],
  decisionReplay: []
});

export const db = blank();

function mergeLoaded(value) {
  Object.assign(db, blank(), value || {});
}

export function persist() {
  fs.mkdirSync(dataDir, { recursive: true });
  fs.writeFileSync(dataFile, JSON.stringify(db, null, 2));
}

function load() {
  if (!fs.existsSync(dataFile)) return false;
  try {
    mergeLoaded(JSON.parse(fs.readFileSync(dataFile, "utf8")));
    return true;
  } catch {
    return false;
  }
}

const providers = [
  { id: "prov_razorpay_demo", name: "Razorpay Demo Route", type: "PSP", status: "HEALTHY", healthScore: 98, successRate: 98.1, latencyMs: 420, volume: 684220, routingWeight: 70 },
  { id: "prov_axis_demo", name: "Axis Bank Demo Rail", type: "BANK_RAIL", status: "HEALTHY", healthScore: 96, successRate: 97.4, latencyMs: 470, volume: 301820, routingWeight: 20 },
  { id: "prov_icici_demo", name: "ICICI Bank Demo Rail", type: "BANK_RAIL", status: "DEGRADED", healthScore: 71, successRate: 91.4, latencyMs: 1240, volume: 262352, routingWeight: 10 }
];

function sampleTransactions() {
  const rails = ["UPI", "CARDS", "NET_BANKING"];
  const statuses = ["SUCCESS", "RECOVERED", "FAILED", "RETRYING", "POLICY BLOCKED"];
  const reasons = ["issuer_timeout", "provider_degradation", "insufficient_funds", "network_timeout", "velocity_policy"];
  return Array.from({ length: 36 }, (_, i) => {
    const status = statuses[i % statuses.length];
    return {
      id: `RX-${(0x8f29a1 + i * 9127).toString(16).toUpperCase().slice(-6)}`,
      timestamp: new Date(Date.now() - i * 47000).toISOString(),
      rail: rails[i % rails.length],
      providerId: providers[i % providers.length].id,
      provider: providers[i % providers.length].name,
      amount: [1299, 2499, 8999, 12450, 18999, 42000, 87500, 145000][i % 8],
      currency: "INR",
      status,
      failureReason: status === "SUCCESS" ? null : reasons[i % reasons.length],
      recoveryAction: status === "RECOVERED" ? ["RETRY", "REROUTE", "DELAY"][i % 3] : null,
      revenueOutcome: status === "RECOVERED" ? "RECOVERED" : status === "SUCCESS" ? "PROTECTED" : "AT_RISK",
      customer: { id: `cust_demo_${i + 1}` },
      pii: false
    };
  });
}

function sampleIncidents() {
  return [{
    id: "INC-20481",
    title: "NET BANKING AUTHORIZATION DEGRADATION",
    severity: "HIGH",
    provider: "ICICI Bank Demo Rail",
    providerId: "prov_icici_demo",
    rail: "NET_BANKING",
    status: "INVESTIGATING",
    detectedAt: new Date(Date.now() - 29 * 60000).toISOString(),
    affectedTransactions: 8421,
    revenueExposure: 1480000,
    failureRate: 7.8,
    rootCause: "Elevated issuer timeout rate",
    aiConfidence: 0.947,
    recommendation: "Shift 35% traffic to alternate route",
    policy: { status: "REQUIRES_HUMAN_APPROVAL", reason: "Routing change exceeds autonomous threshold." }
  }];
}

function samplePredictions() {
  return [{
    id: "PRED-7721",
    provider: "ICICI Bank Demo Rail",
    providerId: "prov_icici_demo",
    rail: "NET_BANKING",
    failureProbability: 0.82,
    horizonMinutes: 5,
    risk: "HIGH",
    confidence: 0.88,
    affectedVolume: 8421,
    revenueExposure: 1820000,
    features: ["failure rate increased", "latency increased", "issuer timeout spike", "similar cohort detected"],
    status: "ACTIVE",
    createdAt: new Date().toISOString()
  }];
}

function sampleRecovery() {
  return [
    { id: "REC-1001", rank: 1, transactionId: "RX-8F29A1", amount: 12450, failure: "issuer_timeout", provider: "ICICI Bank Demo Rail", recoveryProbability: 0.74, expectedRecovery: 9213, risk: "LOW", priorityScore: 91, recommendedAction: "REROUTE", status: "READY", requiresApproval: true },
    { id: "REC-1002", rank: 2, transactionId: "RX-91C72D", amount: 42000, failure: "network_timeout", provider: "ICICI Bank Demo Rail", recoveryProbability: 0.68, expectedRecovery: 28560, risk: "MEDIUM", priorityScore: 86, recommendedAction: "RETRY", status: "READY", requiresApproval: false },
    { id: "REC-1003", rank: 3, transactionId: "RX-44BA21", amount: 87500, failure: "provider_degradation", provider: "ICICI Bank Demo Rail", recoveryProbability: 0.81, expectedRecovery: 70875, risk: "MEDIUM", priorityScore: 84, recommendedAction: "ALTERNATE_PROVIDER", status: "READY", requiresApproval: true }
  ];
}

function sampleAgents() {
  const names = [
    ["agent_anomaly", "Anomaly Detection Agent"],
    ["agent_rootcause", "Root Cause Investigation Agent"],
    ["agent_recovery", "Recovery Strategy Agent"],
    ["agent_risk", "Risk & Autonomy Agent"],
    ["agent_outcome", "Outcome & Learning Agent"]
  ];
  return names.map(([id, name], i) => ({
    id, name, status: "ACTIVE", currentTask: ["Scanning provider telemetry", "Investigating issuer timeout pattern", "Evaluating alternate routing strategy", "Validating policy constraints", "Attributing recovery outcome"][i],
    executions: 1240 - i * 81,
    successRate: 0.94 - i * 0.01,
    latencyMs: 84 + i * 19,
    fallbackUsage: 0.02 + i * 0.004,
    confidence: 0.91 + i * 0.012,
    lastAction: new Date(Date.now() - i * 17000).toISOString()
  }));
}

function sampleSeries(days) {
  const points = [];
  for (let i = days - 1; i >= 0; i--) {
    const d = new Date(Date.now() - i * 86400000);
    const risk = Math.round(280000 + Math.sin(i / 2) * 65000 + (days - i) * 2800);
    const recovered = Math.round(risk * (0.64 + (i % 5) * 0.03));
    points.push({ timestamp: d.toISOString(), atRisk: risk, recovered });
  }
  return points;
}

export function seedIfEmpty() {
  if (load() && db.transactions.length) return;
  reseed();
}

export function reseed() {
  Object.assign(db, blank());
  db.users.push({
    id: "usr_demo_operator",
    email: "operator@recoverx.demo",
    name: "Demo Operator",
    role: "OPERATIONS_ADMIN",
    environment: "DEMO"
  });
  db.providers = providers;
  db.transactions = sampleTransactions();
  db.incidents = sampleIncidents();
  db.predictions = samplePredictions();
  db.recoveryQueue = sampleRecovery();
  db.agents = sampleAgents();

  db.routing = providers.map(p => ({
    id: `route_${p.id}`,
    providerId: p.id,
    provider: p.name,
    currentWeight: p.routingWeight,
    recommendedWeight: p.id === "prov_icici_demo" ? 5 : p.id === "prov_axis_demo" ? 55 : 40,
    reason: p.id === "prov_icici_demo" ? "Provider degradation detected" : "Counterfactual strategy improves expected recovery",
    predictionId: "PRED-7721",
    risk: p.id === "prov_icici_demo" ? "HIGH" : "LOW",
    policyStatus: p.id === "prov_icici_demo" ? "REQUIRES_HUMAN_APPROVAL" : "PENDING",
    executionStatus: "NOT_EXECUTED",
    cooldownMinutes: 10
  }));

  db.approvals = [{
    id: "APR-55021",
    action: "Redirect 35% traffic to alternate route",
    transactionId: null,
    amount: 1245000,
    risk: "LOW",
    recommendation: "REROUTE",
    confidence: 0.968,
    reason: "Expected recovery improves while remaining inside configured transaction value threshold.",
    requestedAt: new Date(Date.now() - 12 * 60000).toISOString(),
    status: "PENDING",
    requestedBy: "agent_recovery"
  }];

  db.agentActivity = [
    { id: randomUUID(), timestamp: new Date(Date.now() - 5000).toISOString(), agent: "Anomaly Detection Agent", event: "Detected elevated failure rate", severity: "HIGH" },
    { id: randomUUID(), timestamp: new Date(Date.now() - 4000).toISOString(), agent: "Root Cause Investigation Agent", event: "Identified issuer timeout pattern", severity: "INFO" },
    { id: randomUUID(), timestamp: new Date(Date.now() - 3000).toISOString(), agent: "Digital Twin Simulation Agent", event: "Generated 3 recovery strategies", severity: "INFO" },
    { id: randomUUID(), timestamp: new Date(Date.now() - 2000).toISOString(), agent: "Risk & Autonomy Agent", event: "Validated policy constraints", severity: "INFO" },
    { id: randomUUID(), timestamp: new Date(Date.now() - 1000).toISOString(), agent: "Recovery Strategy Agent", event: "Recommended alternate route", severity: "ACTION" },
    { id: randomUUID(), timestamp: new Date().toISOString(), agent: "Outcome & Learning Agent", event: "Estimated ₹4.8L recoverable value", severity: "INFO" }
  ];

  db.revenue.summary = {
    revenueAtRisk: 4280000,
    expectedRecovery: 3160000,
    recoveredRevenue: 3160000,
    protectedRevenue: 2420000,
    recoveryAttempts: 18492,
    successfulRecoveries: 17502,
    recoveryRate: 0.738,
    recoveryCost: null,
    roi: null
  };
  db.revenue.series24H = sampleSeries(24);
  db.revenue.series7D = sampleSeries(7);
  db.revenue.series30D = sampleSeries(30);
  db.revenue.attribution = [
    { incidentId: "INC-20481", affectedValue: 1480000, recoveredValue: 1095200, strategy: "REROUTE", confidence: 0.947 },
    { incidentId: "INC-20477", affectedValue: 820000, recoveredValue: 574000, strategy: "RETRY", confidence: 0.901 },
    { incidentId: "INC-20463", affectedValue: 610000, recoveredValue: 445300, strategy: "ALTERNATE_PROVIDER", confidence: 0.922 }
  ];

  db.auditLog = [{
    id: randomUUID(),
    timestamp: new Date().toISOString(),
    actor: "system",
    actorType: "SYSTEM",
    action: "DEMO_DATA_INITIALIZED",
    resource: "recoverx",
    outcome: "SUCCESS",
    details: "Safe simulation dataset initialized."
  }];

  db.decisionReplay = db.transactions.slice(0, 10).map(t => ({
    transactionId: t.id,
    events: [
      { timestamp: t.timestamp, actor: "Payment Monitor", event: "Payment event received" },
      { timestamp: new Date(new Date(t.timestamp).getTime() + 70).toISOString(), actor: "Anomaly Detection Agent", event: t.status === "SUCCESS" ? "No anomaly detected" : "Failure pattern detected" },
      { timestamp: new Date(new Date(t.timestamp).getTime() + 160).toISOString(), actor: "Recovery Strategy Agent", event: t.recoveryAction ? `Recommended ${t.recoveryAction}` : "No recovery action required" },
      { timestamp: new Date(new Date(t.timestamp).getTime() + 240).toISOString(), actor: "Risk & Autonomy Agent", event: "Policy evaluation completed" },
      { timestamp: new Date(new Date(t.timestamp).getTime() + 320).toISOString(), actor: "Outcome & Learning Agent", event: `Outcome: ${t.revenueOutcome}` }
    ]
  }));

  persist();
}
