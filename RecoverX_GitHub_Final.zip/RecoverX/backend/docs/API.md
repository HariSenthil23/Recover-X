# RecoverX API Contract

Base URL: `/api`

## Auth

- `POST /auth/login`
- `GET /auth/me`

Login returns `{ token, user }`.

## Dashboard

- `GET /dashboard/summary`
- `GET /dashboard/payment-health`
- `GET /dashboard/live-operations?limit=50`

## Transactions

- `GET /transactions`
  - query: `status`, `rail`, `provider`, `limit`
- `GET /transactions/:id`
- `GET /transactions/:id/timeline`

## Incidents

- `GET /incidents`
  - query: `status`, `severity`
- `GET /incidents/:id`
- `GET /incidents/:id/timeline`
- `POST /incidents/:id/investigate`
- `POST /incidents/:id/simulate`

## Predictions

- `GET /predictions`
- `GET /predictions/:id`

## Recovery

- `GET /recovery/queue`
- `POST /recovery/queue/:id/simulate`
- `POST /recovery/queue/:id/execute`
  - demo-safe execution only; requires approval when the policy says so

## Simulation

- `POST /simulations`
- `GET /simulations/:id`
- `GET /simulations/:id/events`

## Providers

- `GET /providers`
- `GET /providers/:id`

## Routing

- `GET /routing`
- `POST /routing/recommendations/:id/approve`
- `POST /routing/recommendations/:id/reject`

## Approvals

- `GET /approvals`
- `GET /approvals/:id`
- `POST /approvals/:id/approve`
- `POST /approvals/:id/reject` with `{ reason }`

## Agents

- `GET /agents`
- `GET /agents/:id`
- `GET /agents/activity`

## Revenue

- `GET /revenue/summary?range=24H|7D|30D`
- `GET /revenue/series?range=24H|7D|30D`
- `GET /revenue/attribution`

## Audit / replay

- `GET /audit-log`
- `GET /decision-replay/:transactionId`

## Health

- `GET /health`
