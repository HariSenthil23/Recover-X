// Reference sketch only. The actual, fleshed-out client used by the RecoverX
// frontend lives at frontend/src/lib/api.ts (adds error typing, session
// restore, and the live-event subscription used across every screen).

export const API_BASE = import.meta.env.VITE_API_URL ?? "http://localhost:4000/api";

let token = localStorage.getItem("recoverx_token");

export function setToken(value: string | null) {
  token = value;
  if (value) localStorage.setItem("recoverx_token", value);
  else localStorage.removeItem("recoverx_token");
}

export async function api<T>(path: string, init: RequestInit = {}): Promise<T> {
  const res = await fetch(`${API_BASE}${path}`, {
    ...init,
    headers: {
      "Content-Type": "application/json",
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...(init.headers || {})
    }
  });
  if (!res.ok) throw new Error((await res.json().catch(() => ({}))).message || `API ${res.status}`);
  return res.json();
}

export async function login(email: string, password: string) {
  const result = await api<{token:string}>("/auth/login", {
    method: "POST",
    body: JSON.stringify({ email, password })
  });
  setToken(result.token);
  return result;
}

export function connectLive(onMessage: (event: any) => void) {
  if (!token) throw new Error("Login first");
  const wsUrl = API_BASE.replace(/^http/, "ws").replace(/\/api$/, `/ws?token=${encodeURIComponent(token)}`);
  const ws = new WebSocket(wsUrl);
  ws.onmessage = e => onMessage(JSON.parse(e.data));
  return ws;
}
