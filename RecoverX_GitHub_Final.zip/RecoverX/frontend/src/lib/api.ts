// RecoverX API client
// Talks to the RecoverX backend (see backend/README.md). All financial actions
// exposed here are demo-safe simulations — no live money movement occurs.

export const API_BASE = (import.meta as any).env?.VITE_API_URL ?? "http://localhost:4000/api";

const TOKEN_KEY = "recoverx_token";

let token: string | null =
  typeof window !== "undefined" ? window.localStorage.getItem(TOKEN_KEY) : null;

export function getToken() {
  return token;
}

export function setToken(value: string | null) {
  token = value;
  if (typeof window === "undefined") return;
  if (value) window.localStorage.setItem(TOKEN_KEY, value);
  else window.localStorage.removeItem(TOKEN_KEY);
}

export class ApiError extends Error {
  status: number;
  code?: string;
  constructor(message: string, status: number, code?: string) {
    super(message);
    this.status = status;
    this.code = code;
  }
}

async function request<T>(path: string, init: RequestInit = {}): Promise<T> {
  let res: Response;
  try {
    res = await fetch(`${API_BASE}${path}`, {
      ...init,
      headers: {
        "Content-Type": "application/json",
        ...(token ? { Authorization: `Bearer ${token}` } : {}),
        ...(init.headers || {}),
      },
    });
  } catch (err) {
    throw new ApiError(
      "Could not reach the RecoverX backend. Is the server running?",
      0,
      "NETWORK_ERROR"
    );
  }

  const isJson = res.headers.get("content-type")?.includes("application/json");
  const body = isJson ? await res.json().catch(() => ({})) : undefined;

  if (!res.ok) {
    throw new ApiError(
      body?.message || `Request failed (${res.status})`,
      res.status,
      body?.error
    );
  }
  return body as T;
}

export const api = {
  get: <T>(path: string) => request<T>(path, { method: "GET" }),
  post: <T>(path: string, data?: unknown) =>
    request<T>(path, { method: "POST", body: data ? JSON.stringify(data) : undefined }),
};

// ---------- Auth ----------

export interface AuthUser {
  id: string;
  email: string;
  name: string;
  role: string;
  environment: string;
}

export async function login(email: string, password: string) {
  const result = await api.post<{ token: string; user: AuthUser }>("/auth/login", {
    email,
    password,
  });
  setToken(result.token);
  return result;
}

export function logout() {
  setToken(null);
}

export async function fetchMe() {
  return api.get<{ user: AuthUser | null }>("/auth/me");
}

// ---------- Live WebSocket stream ----------

export type LiveEvent = { type: string; data: unknown; ts: string };

export function connectLive(onMessage: (event: LiveEvent) => void, onStatus?: (connected: boolean) => void) {
  if (!token) return null;
  const wsUrl = API_BASE.replace(/^http/, "ws").replace(/\/api\/?$/, `/ws?token=${encodeURIComponent(token)}`);
  const ws = new WebSocket(wsUrl);
  ws.onopen = () => onStatus?.(true);
  ws.onclose = () => onStatus?.(false);
  ws.onerror = () => onStatus?.(false);
  ws.onmessage = (e) => {
    try {
      onMessage(JSON.parse(e.data));
    } catch {
      // ignore malformed frames
    }
  };
  return ws;
}
