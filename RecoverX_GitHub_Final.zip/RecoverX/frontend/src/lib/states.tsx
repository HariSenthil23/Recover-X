import { AlertTriangle, Loader2, Inbox } from "lucide-react";

export function LoadingState({ label = "Loading…" }: { label?: string }) {
  return (
    <div className="flex flex-col items-center justify-center py-16 text-muted-foreground gap-3">
      <Loader2 className="w-5 h-5 animate-spin text-primary" />
      <span className="text-[11px] font-mono uppercase tracking-widest">{label}</span>
    </div>
  );
}

export function ErrorState({ message, onRetry }: { message: string; onRetry?: () => void }) {
  return (
    <div className="flex flex-col items-center justify-center py-16 text-center gap-3">
      <AlertTriangle className="w-6 h-6 text-red-500" />
      <p className="text-sm text-foreground/80 max-w-sm">{message}</p>
      {onRetry && (
        <button
          onClick={onRetry}
          className="px-4 py-2 border border-border hover:bg-secondary rounded text-[11px] font-mono font-bold tracking-widest uppercase transition-colors text-foreground"
        >
          RETRY
        </button>
      )}
    </div>
  );
}

export function EmptyState({ label = "Nothing here yet." }: { label?: string }) {
  return (
    <div className="flex flex-col items-center justify-center py-16 text-muted-foreground gap-3">
      <Inbox className="w-6 h-6 opacity-50" />
      <span className="text-[11px] font-mono uppercase tracking-widest">{label}</span>
    </div>
  );
}
