import { useCallback, useEffect, useRef, useState } from "react";
import { api, ApiError } from "./api";

interface UseApiState<T> {
  data: T | null;
  loading: boolean;
  error: string | null;
  refresh: () => void;
}

// Fetches `path` on mount and whenever `deps` change. Exposes loading/error
// so views can render skeletons and inline error states instead of crashing.
export function useApiGet<T>(path: string | null, deps: unknown[] = []): UseApiState<T> {
  const [data, setData] = useState<T | null>(null);
  const [loading, setLoading] = useState(!!path);
  const [error, setError] = useState<string | null>(null);
  const nonce = useRef(0);

  const load = useCallback(() => {
    if (!path) return;
    const my = ++nonce.current;
    setLoading(true);
    setError(null);
    api
      .get<T>(path)
      .then((res) => {
        if (nonce.current === my) {
          setData(res);
          setLoading(false);
        }
      })
      .catch((err: unknown) => {
        if (nonce.current === my) {
          setError(err instanceof ApiError ? err.message : "Something went wrong.");
          setLoading(false);
        }
      });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [path, ...deps]);

  useEffect(() => {
    load();
  }, [load]);

  return { data, loading, error, refresh: load };
}

export function formatINR(amount: number | null | undefined) {
  if (amount === null || amount === undefined) return "—";
  if (Math.abs(amount) >= 10000000) return `₹${(amount / 10000000).toFixed(2)} Cr`;
  if (Math.abs(amount) >= 100000) return `₹${(amount / 100000).toFixed(2)} L`;
  return `₹${amount.toLocaleString("en-IN")}`;
}

export function formatTime(iso: string | null | undefined) {
  if (!iso) return "—";
  try {
    return new Date(iso).toLocaleTimeString("en-IN", { hour12: false });
  } catch {
    return iso;
  }
}

export function formatDateTime(iso: string | null | undefined) {
  if (!iso) return "—";
  try {
    return new Date(iso).toLocaleString("en-IN");
  } catch {
    return iso;
  }
}
