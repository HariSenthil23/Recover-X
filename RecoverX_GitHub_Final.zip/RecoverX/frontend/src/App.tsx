import React, { useState, useEffect } from 'react';
import { 
  Activity, AlertTriangle, ArrowRightLeft, CheckCircle2, ChevronRight, 
  Clock, Command, DollarSign, LayoutDashboard, 
  LogOut, Settings, Shield, ShieldAlert, TerminalSquare, 
  Zap, RefreshCw, Bell, Search, TrendingUp, TrendingDown,
  BrainCircuit, Database, FileClock, Lock, LifeBuoy, Info,
  Sun, Moon, LayoutGrid, SlidersHorizontal, ListEnd, 
  TableProperties, Layers, Route, BadgeCheck, ClipboardList,
  User, Globe, RotateCcw, X
} from 'lucide-react';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';
import { motion, AnimatePresence } from 'framer-motion';
import { api, API_BASE, login as apiLogin, logout as apiLogout, getToken, fetchMe, connectLive, type AuthUser, type LiveEvent } from './lib/api';
import { useApiGet, formatINR, formatTime, formatDateTime } from './lib/hooks';
import { LoadingState, ErrorState, EmptyState } from './lib/states';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

// Simple counter animation hook
function useAnimatedCounter(endValue: number, duration: number = 2000) {
  const [value, setValue] = useState(0);

  useEffect(() => {
    let startTimestamp: number | null = null;
    const step = (timestamp: number) => {
      if (!startTimestamp) startTimestamp = timestamp;
      const progress = Math.min((timestamp - startTimestamp) / duration, 1);
      // ease out expo
      const ease = 1 - Math.pow(1 - progress, 3);
      setValue(Math.floor(ease * endValue));
      if (progress < 1) {
        window.requestAnimationFrame(step);
      }
    };
    window.requestAnimationFrame(step);
  }, [endValue, duration]);

  return value;
}

// Theme Hook
function useTheme() {
  const [isDark, setIsDark] = useState(true);
  
  useEffect(() => {
    const isDarkTheme = document.documentElement.classList.contains('dark');
    setIsDark(isDarkTheme);
  }, []);

  const toggleTheme = () => {
    const root = document.documentElement;
    if (root.classList.contains('dark')) {
      root.classList.remove('dark');
      setIsDark(false);
    } else {
      root.classList.add('dark');
      setIsDark(true);
    }
  };

  return { isDark, toggleTheme };
}

type ViewState = 'LANDING' | 'LOGIN' | 'APP';

export default function App() {
  const [view, setView] = useState<ViewState>('LANDING');
  const [activeTab, setActiveTab] = useState('COMMAND CENTER');
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);
  const [user, setUser] = useState<AuthUser | null>(null);
  const [sessionChecked, setSessionChecked] = useState(false);
  const [apiMode, setApiMode] = useState<'demo' | 'integration' | 'offline'>('demo');
  const [liveConnected, setLiveConnected] = useState(false);
  const [notifications, setNotifications] = useState<{ id: string; title: string; body: string; ts: string; tone: 'critical' | 'primary' }[]>([]);
  const [refreshKey, setRefreshKey] = useState(0);

  const { isDark, toggleTheme } = useTheme();

  // Resume a session if a token is already stored (e.g. page refresh).
  useEffect(() => {
    const token = getToken();
    if (!token) { setSessionChecked(true); return; }
    fetchMe()
      .then(res => {
        if (res.user) { setUser(res.user); setView('APP'); }
      })
      .catch(() => apiLogout())
      .finally(() => setSessionChecked(true));
  }, []);

  // Backend health/mode indicator (demo vs. live integration).
  useEffect(() => {
    let cancelled = false;
    fetch(`${API_BASE}/health`)
      .then(r => r.json())
      .then(d => { if (!cancelled) setApiMode(d.mode === 'integration' ? 'integration' : 'demo'); })
      .catch(() => { if (!cancelled) setApiMode('offline'); });
    return () => { cancelled = true; };
  }, [view]);

  // Live event stream: keeps the notification bell current across every screen.
  useEffect(() => {
    if (view !== 'APP') return;
    const ws = connectLive((evt: LiveEvent) => {
      if (evt.type === 'incident_update') {
        const d = evt.data as any;
        setNotifications(n => [{ id: `${evt.type}-${Date.now()}`, title: 'Incident updated', body: `${d.id}: ${d.status}`, ts: evt.ts, tone: 'critical' as const }, ...n].slice(0, 20));
      }
      if (evt.type === 'approval_update') {
        const d = evt.data as any;
        setNotifications(n => [{ id: `${evt.type}-${Date.now()}`, title: 'Approval activity', body: d.action || d.id, ts: evt.ts, tone: 'primary' as const }, ...n].slice(0, 20));
      }
    }, setLiveConnected);
    return () => ws?.close();
  }, [view]);

  const handleRefresh = () => {
    setIsRefreshing(true);
    setRefreshKey(k => k + 1);
    setTimeout(() => setIsRefreshing(false), 800);
  };

  const handleLogout = () => {
    apiLogout();
    setUser(null);
    setView('LANDING');
  };

  if (!sessionChecked) {
    return (
      <div className="flex h-screen w-full items-center justify-center bg-background">
        <LoadingState label="Restoring session…" />
      </div>
    );
  }

  if (view === 'LANDING') {
    return <LandingView onLoginClick={() => setView('LOGIN')} isDark={isDark} toggleTheme={toggleTheme} />;
  }

  if (view === 'LOGIN') {
    return <LoginView onLogin={(u) => { setUser(u); setView('APP'); }} onBack={() => setView('LANDING')} isDark={isDark} />;
  }

  return (
    <div className="flex h-screen w-full bg-background text-foreground overflow-hidden selection:bg-primary/30 transition-colors duration-300">
      {/* SIDEBAR */}
      <aside className="w-64 border-r border-border bg-card/60 backdrop-blur-md flex flex-col justify-between shrink-0 relative z-20">
        <div>
          <div className="h-16 flex items-center px-6 border-b border-border">
            <div className="flex items-center gap-2 text-primary font-semibold tracking-tight">
              <ShieldAlert className="w-5 h-5 drop-shadow-[0_0_8px_currentColor]" />
              <span className="tracking-widest">RECOVERX</span>
            </div>
          </div>
          
          <nav className="p-4 space-y-1 overflow-y-auto max-h-[calc(100vh-140px)] scrollbar-hide">
            <div className="text-[10px] font-mono text-muted-foreground mb-3 mt-2 px-2 uppercase tracking-widest">Operations</div>
            <NavItem icon={LayoutGrid} label="Command Center" active={activeTab === 'COMMAND CENTER'} onClick={() => setActiveTab('COMMAND CENTER')} />
            <NavItem icon={AlertTriangle} label="Incidents" active={activeTab === 'INCIDENTS'} onClick={() => setActiveTab('INCIDENTS')} />
            <NavItem icon={SlidersHorizontal} label="Predictions" active={activeTab === 'PREDICTIONS'} onClick={() => setActiveTab('PREDICTIONS')} />
            <NavItem icon={ListEnd} label="Recovery Queue" active={activeTab === 'RECOVERY QUEUE'} onClick={() => setActiveTab('RECOVERY QUEUE')} />
            <NavItem icon={TableProperties} label="Simulations" active={activeTab === 'SIMULATIONS'} onClick={() => setActiveTab('SIMULATIONS')} />
            
            <div className="text-[10px] font-mono text-muted-foreground mb-3 mt-6 px-2 uppercase tracking-widest">Infrastructure</div>
            <NavItem icon={Layers} label="Providers" active={activeTab === 'PROVIDERS'} onClick={() => setActiveTab('PROVIDERS')} />
            <NavItem icon={Route} label="Routing" active={activeTab === 'ROUTING'} onClick={() => setActiveTab('ROUTING')} />
            
            <div className="text-[10px] font-mono text-muted-foreground mb-3 mt-6 px-2 uppercase tracking-widest">Governance</div>
            <NavItem icon={BadgeCheck} label="Approvals" active={activeTab === 'APPROVALS'} onClick={() => setActiveTab('APPROVALS')} />
            <NavItem icon={DollarSign} label="Revenue" active={activeTab === 'REVENUE'} onClick={() => setActiveTab('REVENUE')} />
            <NavItem icon={ClipboardList} label="Audit Log" active={activeTab === 'AUDIT LOG'} onClick={() => setActiveTab('AUDIT LOG')} />
            
            <div className="text-[10px] font-mono text-muted-foreground mb-3 mt-6 px-2 uppercase tracking-widest">Intelligence</div>
            <NavItem icon={User} label="AI Agents" active={activeTab === 'AI AGENTS'} onClick={() => setActiveTab('AI AGENTS')} />
            <NavItem icon={RotateCcw} label="Decision Replay" active={activeTab === 'DECISION REPLAY'} onClick={() => setActiveTab('DECISION REPLAY')} />
            <NavItem icon={Settings} label="Settings" active={activeTab === 'SETTINGS'} onClick={() => setActiveTab('SETTINGS')} />
          </nav>
        </div>
        
        <div className="p-4 border-t border-border bg-card/40">
          <div className="flex flex-col gap-1 mb-3 px-2">
            <div className={cn("flex items-center gap-2 text-[10px] font-mono font-bold", liveConnected ? "text-emerald-500 dark:text-emerald-400" : "text-muted-foreground")}>
              <div className={cn("w-1.5 h-1.5 rounded-full", liveConnected ? "bg-emerald-500 dark:bg-emerald-400 shadow-[0_0_8px_rgba(52,211,153,0.8)] animate-pulse" : "bg-muted-foreground")} />
              {liveConnected ? "LIVE STREAM CONNECTED" : "LIVE STREAM OFFLINE"}
            </div>
          </div>
          <div className="flex items-center gap-3 px-2 py-2 rounded-md hover:bg-black/5 dark:hover:bg-white/5 transition-colors cursor-pointer group" onClick={handleLogout}>
            <div className="w-8 h-8 rounded-md bg-primary/10 flex items-center justify-center text-primary font-mono text-sm border border-primary/20">
              {(user?.name || 'OP').split(' ').map(w => w[0]).join('').slice(0,2).toUpperCase()}
            </div>
            <div className="flex-1 overflow-hidden">
              <div className="text-sm font-medium truncate">{user?.name || 'Operator'}</div>
              <div className="text-[10px] text-muted-foreground truncate font-mono">{user?.email || 'operator@recoverx.demo'}</div>
            </div>
            <LogOut className="w-4 h-4 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity" />
          </div>
        </div>
      </aside>

      {/* MAIN CONTENT */}
      <main className="flex-1 flex flex-col min-w-0 bg-background relative z-10 transition-colors duration-300">
        <div className="absolute inset-0 pointer-events-none opacity-[0.05] dark:opacity-[0.02]" style={{ backgroundImage: 'linear-gradient(var(--border) 1px, transparent 1px), linear-gradient(90deg, var(--border) 1px, transparent 1px)', backgroundSize: '40px 40px' }} />
        
        <header className="h-16 border-b border-border flex items-center justify-between px-8 bg-card/80 backdrop-blur-md shrink-0 sticky top-0 z-20">
          <div>
            <h1 className="text-lg font-semibold tracking-tight">RecoverX {activeTab}</h1>
            <p className="text-[10px] text-primary font-mono mt-0.5 tracking-wider uppercase">AI-Native Operations Console</p>
          </div>
          <div className="flex items-center gap-4">
            <div className="flex flex-col items-end mr-4">
              <span className="text-[10px] font-mono text-muted-foreground tracking-widest">ENVIRONMENT</span>
              <span className={cn("text-xs font-mono font-bold drop-shadow-[0_0_4px_rgba(245,158,11,0.5)]", apiMode === 'offline' ? "text-red-500" : apiMode === 'integration' ? "text-emerald-500" : "text-amber-600 dark:text-amber-500")}>
                {apiMode === 'offline' ? 'BACKEND OFFLINE' : apiMode === 'integration' ? 'LIVE INTEGRATION' : 'DEMO SIMULATION'}
              </span>
            </div>
            
            <button 
              onClick={toggleTheme}
              className="text-muted-foreground hover:text-foreground transition-colors p-2"
              title="Toggle Theme"
            >
              {isDark ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
            </button>
            <div className="h-6 w-px bg-border mx-1" />
            <button 
              onClick={handleRefresh}
              className="text-muted-foreground hover:text-foreground transition-colors p-2"
            >
              <RefreshCw className={cn("w-4 h-4", isRefreshing && "animate-spin")} />
            </button>
            <div className="relative">
              <button 
                onClick={() => setShowNotifications(!showNotifications)}
                className="text-muted-foreground hover:text-foreground transition-colors p-2 relative"
              >
                <Bell className="w-4 h-4" />
                {notifications.length > 0 && (
                  <span className="absolute top-1.5 right-1.5 w-1.5 h-1.5 rounded-full bg-red-500 ring-2 ring-card shadow-[0_0_8px_rgba(239,68,68,0.8)]" />
                )}
              </button>
              
              <AnimatePresence>
                {showNotifications && (
                  <motion.div 
                    initial={{ opacity: 0, y: 10, scale: 0.95 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, y: 10, scale: 0.95 }}
                    transition={{ duration: 0.15 }}
                    className="absolute right-0 mt-2 w-80 bg-card border border-border rounded-lg shadow-2xl z-50 overflow-hidden"
                  >
                    <div className="p-3 border-b border-border flex justify-between items-center bg-secondary/50">
                      <span className="text-sm font-semibold tracking-wide">Notifications</span>
                      <button 
                        onClick={() => setNotifications([])}
                        className="text-[10px] font-mono text-primary hover:text-primary/80 transition-colors"
                      >
                        CLEAR ALL
                      </button>
                    </div>
                    <div className="max-h-80 overflow-y-auto divide-y divide-border">
                      {notifications.length === 0 && (
                        <div className="p-6 text-center text-xs text-muted-foreground font-mono">No live events yet.</div>
                      )}
                      {notifications.map(n => (
                        <div key={n.id} className="p-4 hover:bg-black/5 dark:hover:bg-white/5 transition-colors cursor-pointer">
                          <div className="flex justify-between items-start mb-1">
                            <span className={cn("text-xs font-semibold", n.tone === 'critical' ? "text-red-500 dark:text-red-400" : "text-primary")}>{n.title}</span>
                            <span className="text-[10px] font-mono text-muted-foreground">{formatTime(n.ts)}</span>
                          </div>
                          <p className="text-xs text-muted-foreground">{n.body}</p>
                        </div>
                      ))}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </div>
        </header>
        
        <div className="flex-1 overflow-y-auto p-8 relative z-10">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeTab}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.3 }}
              className="max-w-[1400px] mx-auto space-y-8"
            >
              {activeTab === 'COMMAND CENTER' && <CommandCenterView refreshKey={refreshKey} onNavigate={setActiveTab} />}
              {activeTab === 'INCIDENTS' && <IncidentsView refreshKey={refreshKey} />}
              {activeTab === 'PREDICTIONS' && <PredictionsView refreshKey={refreshKey} />}
              {activeTab === 'RECOVERY QUEUE' && <RecoveryQueueView refreshKey={refreshKey} />}
              {activeTab === 'SIMULATIONS' && <SimulationsView refreshKey={refreshKey} />}
              {activeTab === 'PROVIDERS' && <ProvidersView refreshKey={refreshKey} />}
              {activeTab === 'ROUTING' && <RoutingView refreshKey={refreshKey} />}
              {activeTab === 'APPROVALS' && <ApprovalsView refreshKey={refreshKey} />}
              {activeTab === 'REVENUE' && <RevenueView refreshKey={refreshKey} />}
              {activeTab === 'AUDIT LOG' && <AuditLogView refreshKey={refreshKey} />}
              {activeTab === 'AI AGENTS' && <AgentsView refreshKey={refreshKey} />}
              {activeTab === 'DECISION REPLAY' && <DecisionReplayView refreshKey={refreshKey} />}
              {activeTab === 'SETTINGS' && <SettingsView user={user} apiMode={apiMode} onReset={handleRefresh} />}
            </motion.div>
          </AnimatePresence>
        </div>
      </main>
    </div>
  );
}

// --- Landing View ---

function LandingView({ onLoginClick, isDark, toggleTheme }: { onLoginClick: () => void, isDark: boolean, toggleTheme: () => void }) {
  const scrollToSection = (id: string) => {
    const el = document.getElementById(id);
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  const txnCount = useAnimatedCounter(1240000, 3000);
  const revenueCount = useAnimatedCounter(28400000, 3000);
  const predictedCount = useAnimatedCounter(18492, 3000);

  return (
    <div className="min-h-screen w-full bg-background overflow-x-hidden selection:bg-primary/30 transition-colors duration-300">
      <div className="fixed inset-0 opacity-[0.05] dark:opacity-[0.03] pointer-events-none" style={{ backgroundImage: 'linear-gradient(var(--border) 1px, transparent 1px), linear-gradient(90deg, var(--border) 1px, transparent 1px)', backgroundSize: '40px 40px' }} />
      
      {/* Header */}
      <header className="fixed top-0 w-full h-16 border-b border-border bg-background/90 backdrop-blur-md z-50 px-8 flex items-center justify-between">
        <div className="flex items-center gap-2 text-primary font-semibold tracking-tight cursor-pointer" onClick={() => scrollToSection('hero')}>
          <ShieldAlert className="w-5 h-5 drop-shadow-[0_0_8px_rgba(14,165,233,0.8)]" />
          <span className="tracking-widest">RECOVERX</span>
        </div>
        
        <nav className="hidden md:flex items-center gap-8 text-[11px] font-mono tracking-widest uppercase">
          <button onClick={() => scrollToSection('hero')} className="text-muted-foreground hover:text-primary transition-colors">Platform</button>
          <button onClick={() => scrollToSection('workflow')} className="text-muted-foreground hover:text-primary transition-colors">Workflow</button>
        </nav>
        
        <div className="flex items-center gap-4">
          <button 
            onClick={toggleTheme}
            className="text-muted-foreground hover:text-primary transition-colors p-2"
            title="Toggle Theme"
          >
            {isDark ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
          </button>
          <div className="h-6 w-px bg-border" />
          <button 
            onClick={onLoginClick}
            className="px-5 py-2 bg-primary/10 hover:bg-primary/20 text-primary border border-primary/30 rounded text-[11px] font-mono font-bold tracking-widest transition-all shadow-[0_0_15px_rgba(14,165,233,0.15)] flex items-center gap-2"
          >
            LOGIN
          </button>
        </div>
      </header>

      <div className="relative z-10 pt-16">
        
        {/* HERO SECTION */}
        <section id="hero" className="min-h-[90vh] flex flex-col items-center justify-center px-8 relative">
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-primary/5 dark:bg-primary/10 rounded-full blur-[150px] pointer-events-none" />
          
          <div className="w-full max-w-6xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            
            <motion.div 
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, ease: "easeOut" }}
              className="lg:col-span-8 text-left"
            >
              <div className="inline-flex items-center gap-2 px-3 py-1 bg-secondary border border-border rounded-full mb-8 shadow-sm">
                <div className="w-2 h-2 rounded-full bg-emerald-500 dark:bg-emerald-400 animate-pulse shadow-[0_0_8px_rgba(52,211,153,0.8)]" />
                <span className="text-[10px] font-mono text-muted-foreground uppercase tracking-widest">RECOVERX CORE OPERATIONAL · SIMULATION MODE</span>
              </div>
              
              <h1 className="text-5xl md:text-7xl font-bold tracking-tight mb-6 text-foreground leading-tight">
                RECOVERX
              </h1>
              <h2 className="text-xl md:text-3xl font-light text-primary mb-8 tracking-wide">
                AI-NATIVE PAYMENT RELIABILITY
              </h2>
              <div className="text-lg md:text-xl text-muted-foreground max-w-2xl mb-12 space-y-2 font-light">
                <p>Predict payment failures before they happen.</p>
                <p>Investigate root causes automatically.</p>
                <p>Simulate recovery strategies.</p>
                <p>Recover revenue with policy-controlled autonomous execution.</p>
              </div>
              
              <div className="flex flex-col sm:flex-row items-center gap-6">
                <button 
                  onClick={onLoginClick}
                  className="px-8 py-4 bg-primary hover:bg-primary/90 text-primary-foreground rounded text-sm font-semibold tracking-widest uppercase transition-all shadow-[0_0_20px_rgba(14,165,233,0.4)] flex items-center gap-3 w-full sm:w-auto justify-center"
                >
                  ENTER OPERATIONS <ChevronRight className="w-4 h-4" />
                </button>
                <button 
                  onClick={() => scrollToSection('workflow')}
                  className="px-8 py-4 bg-transparent border border-border hover:border-primary/50 text-foreground rounded text-sm font-semibold tracking-widest uppercase transition-all w-full sm:w-auto justify-center flex items-center gap-3"
                >
                  HOW IT WORKS <ArrowRightLeft className="w-4 h-4" />
                </button>
              </div>
            </motion.div>

            {/* LIVE TELEMETRY PANEL */}
            <motion.div
              initial={{ opacity: 0, x: 30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, delay: 0.2, ease: "easeOut" }}
              className="lg:col-span-4"
            >
              <div className="bg-card border border-border p-6 rounded-xl relative overflow-hidden shadow-2xl">
                <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-primary to-emerald-400" />
                
                <div className="flex justify-between items-center mb-6">
                  <h3 className="text-xs font-mono font-bold tracking-widest text-primary">LIVE TELEMETRY</h3>
                  <span className="text-[9px] bg-primary/10 text-primary px-2 py-1 rounded font-mono border border-primary/20">SIMULATED</span>
                </div>

                <div className="space-y-6">
                  <div>
                    <div className="flex justify-between items-end mb-1">
                      <span className="text-[11px] font-mono text-muted-foreground uppercase">Transactions monitored</span>
                      <span className="text-lg font-mono font-bold text-foreground">{(txnCount + 4000).toLocaleString()}</span>
                    </div>
                    <div className="w-full bg-secondary h-1 rounded-full overflow-hidden">
                      <div className="bg-primary h-full w-[85%]" />
                    </div>
                  </div>
                  
                  <div>
                    <div className="flex justify-between items-end mb-1">
                      <span className="text-[11px] font-mono text-muted-foreground uppercase">Success rate</span>
                      <span className="text-lg font-mono font-bold text-emerald-600 dark:text-emerald-400">97.84%</span>
                    </div>
                  </div>
                  
                  <div>
                    <div className="flex justify-between items-end mb-1">
                      <span className="text-[11px] font-mono text-muted-foreground uppercase">Predicted failures</span>
                      <span className="text-lg font-mono font-bold text-amber-600 dark:text-amber-400">{predictedCount.toLocaleString()}</span>
                    </div>
                  </div>
                  
                  <div>
                    <div className="flex justify-between items-end mb-1">
                      <span className="text-[11px] font-mono text-muted-foreground uppercase">Revenue protected</span>
                      <span className="text-lg font-mono font-bold text-emerald-600 dark:text-emerald-400">₹{(revenueCount / 10000000).toFixed(2)}Cr</span>
                    </div>
                  </div>

                  <div>
                    <div className="flex justify-between items-end mb-1">
                      <span className="text-[11px] font-mono text-muted-foreground uppercase">Avg recovery latency</span>
                      <span className="text-lg font-mono font-bold text-primary">420ms</span>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </section>

        {/* CORE VALUES */}
        <section className="py-24 px-8 border-t border-border bg-secondary/20">
          <div className="max-w-6xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-8">
            <ValueCard 
              icon={BrainCircuit} 
              title="Predictive Core" 
              desc="Detect degradation and anomalies before widespread transaction failure."
              indicator="ANOMALY DETECTION"
              indicatorVal="98.2% CONFIDENCE"
              color="text-primary"
            />
            <ValueCard 
              icon={ArrowRightLeft} 
              title="Agentic Recovery" 
              desc="Autonomously evaluate retry, rerouting and recovery strategies under policy controls."
              indicator="RECOVERY ORCHESTRATION"
              indicatorVal="ACTIVE"
              color="text-emerald-600 dark:text-emerald-400"
            />
            <ValueCard 
              icon={DollarSign} 
              title="Revenue Focus" 
              desc="Measure recovered transaction value and attribute protected revenue to every intervention."
              indicator="REVENUE ATTRIBUTION"
              indicatorVal="REAL-TIME"
              color="text-amber-600 dark:text-amber-400"
            />
          </div>
        </section>

        {/* WORKFLOW PIPELINE */}
        <section id="workflow" className="py-24 px-8 border-t border-border">
          <div className="max-w-5xl mx-auto text-center">
            <h2 className="text-3xl font-bold tracking-tight mb-4">Platform Workflow</h2>
            <p className="text-muted-foreground mb-20 max-w-2xl mx-auto font-light">
              Observe, predict, and recover. The lifecycle operates in milliseconds across the payment infrastructure.
            </p>
            
            <div className="relative">
              <div className="absolute top-1/2 left-[10%] right-[10%] h-px bg-border -translate-y-1/2 hidden md:block" />
              <div className="absolute top-1/2 left-[10%] w-[40%] h-px bg-primary shadow-[0_0_10px_rgba(14,165,233,0.8)] -translate-y-1/2 hidden md:block opacity-50" />
              
              <div className="grid grid-cols-1 md:grid-cols-4 gap-6 relative z-10">
                <WorkflowNode step="1" title="PAYMENT EVENT" active={true} />
                <WorkflowNode step="2" title="ANOMALY DETECT" active={true} />
                <WorkflowNode step="3" title="SIMULATE STRATEGY" active={true} isHighlighted />
                <WorkflowNode step="4" title="RECOVER & ATTRIBUTE" active={false} />
              </div>
            </div>

            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="mt-16 bg-card border border-border rounded-xl p-8 max-w-2xl mx-auto text-left shadow-2xl relative overflow-hidden"
            >
              <div className="absolute top-0 left-0 w-1 h-full bg-primary" />
              <h4 className="font-mono text-xs text-primary mb-4 tracking-widest uppercase font-bold">ROOT CAUSE INVESTIGATION</h4>
              <div className="space-y-4 text-sm font-light">
                <div className="grid grid-cols-2 gap-4 border-b border-border pb-4">
                  <div>
                    <div className="text-muted-foreground mb-1 text-[10px] font-mono uppercase font-bold">Agent Identified</div>
                    <div className="font-medium text-foreground">Issuer authorization degradation</div>
                  </div>
                  <div>
                    <div className="text-muted-foreground mb-1 text-[10px] font-mono uppercase font-bold">Confidence</div>
                    <div className="font-mono text-primary font-bold">94.7%</div>
                  </div>
                </div>
                <div>
                  <div className="text-muted-foreground mb-2 text-[10px] font-mono uppercase font-bold">Observed Signals</div>
                  <ul className="space-y-1 text-foreground/80 font-mono text-xs">
                    <li>• authorization latency +31%</li>
                    <li>• decline rate +18%</li>
                    <li>• issuer timeout spike</li>
                    <li>• affected transaction cohort detected</li>
                  </ul>
                </div>
              </div>
            </motion.div>
          </div>
        </section>

      </div>
    </div>
  );
}

function ValueCard({ icon: Icon, title, desc, indicator, indicatorVal, color }: any) {
  return (
    <motion.div 
      whileHover={{ y: -5 }}
      className="bg-card border border-border hover:border-primary/50 p-8 rounded-xl shadow-lg transition-all duration-300 group relative overflow-hidden"
    >
      <div className="absolute inset-0 bg-gradient-to-b from-primary/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
      <Icon className={cn("w-10 h-10 mb-6 drop-shadow-[0_0_10px_currentColor]", color)} />
      <h3 className="font-semibold text-xl mb-3 text-foreground tracking-wide">{title}</h3>
      <p className="text-muted-foreground text-sm font-light leading-relaxed mb-8">{desc}</p>
      
      <div className="pt-4 border-t border-border">
        <div className="text-[9px] font-mono text-muted-foreground uppercase tracking-widest mb-1 font-bold">{indicator}</div>
        <div className={cn("text-[10px] font-mono font-bold tracking-widest uppercase transition-all", color)}>
          {indicatorVal}
        </div>
      </div>
    </motion.div>
  );
}

function WorkflowNode({ step, title, active, isHighlighted }: any) {
  return (
    <div className="flex flex-col items-center relative">
      <div className={cn(
        "w-12 h-12 rounded-full border-2 flex items-center justify-center font-mono font-bold text-sm mb-4 transition-all duration-500 relative z-10 bg-card",
        active ? "border-primary text-primary" : "border-border text-muted-foreground",
        isHighlighted && "shadow-[0_0_20px_rgba(14,165,233,0.5)] border-primary bg-primary/10"
      )}>
        {step}
      </div>
      <div className={cn(
        "text-[10px] font-mono tracking-widest uppercase text-center w-full max-w-[120px]",
        active ? "text-foreground font-bold" : "text-muted-foreground",
        isHighlighted && "text-primary font-bold"
      )}>
        {title}
      </div>
    </div>
  );
}

function LoginView({ onLogin, onBack, isDark }: { onLogin: (user: AuthUser) => void, onBack: () => void, isDark: boolean }) {
  const [email, setEmail] = useState('operator@recoverx.demo');
  const [password, setPassword] = useState('recoverx-demo');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    try {
      const { user } = await apiLogin(email, password);
      onLogin(user);
    } catch (err: any) {
      setError(err?.message || 'Login failed. Check the backend is running.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex h-screen w-full bg-background items-center justify-center relative overflow-hidden transition-colors duration-300">
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-primary/5 dark:bg-primary/10 rounded-full blur-[150px] pointer-events-none" />
      <div className="absolute inset-0 pointer-events-none opacity-[0.05] dark:opacity-[0.02]" style={{ backgroundImage: 'linear-gradient(var(--border) 1px, transparent 1px), linear-gradient(90deg, var(--border) 1px, transparent 1px)', backgroundSize: '40px 40px' }} />
      
      <button 
        onClick={onBack}
        className="absolute top-8 left-8 flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors text-[11px] font-mono tracking-widest uppercase z-20 font-bold"
      >
        <ChevronRight className="w-4 h-4 rotate-180" /> BACK TO PLATFORM
      </button>

      <motion.div 
        initial={{ opacity: 0, scale: 0.98, y: 10 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        transition={{ duration: 0.4, ease: "easeOut" }}
        className="w-full max-w-md bg-card border border-border rounded-2xl shadow-2xl p-10 relative z-10"
      >
        <div className="flex flex-col items-center mb-10 text-center">
          <div className="w-14 h-14 bg-primary/10 rounded-2xl flex items-center justify-center mb-6 border border-primary/20 shadow-[0_0_15px_rgba(14,165,233,0.2)]">
            <ShieldAlert className="w-7 h-7 text-primary" />
          </div>
          <h1 className="text-3xl font-bold tracking-tight mb-2 text-foreground">RECOVERX</h1>
          <p className="text-[11px] text-primary font-mono tracking-widest uppercase font-bold">OPERATIONS CONSOLE</p>
          <p className="text-sm text-muted-foreground mt-2 font-light">Secure Enterprise Access</p>
        </div>

        <form className="space-y-5" onSubmit={handleSubmit}>
          <div>
            <label className="text-[10px] font-mono text-muted-foreground mb-2 block uppercase tracking-widest font-bold">Work Email</label>
            <input 
              type="email" 
              value={email}
              onChange={e => setEmail(e.target.value)}
              required
              className="w-full bg-secondary border border-border rounded-lg px-4 py-3 text-sm focus:outline-none focus:ring-1 focus:ring-primary font-mono text-foreground"
            />
          </div>
          <div>
            <label className="text-[10px] font-mono text-muted-foreground mb-2 block uppercase tracking-widest font-bold">Password</label>
            <div className="relative">
              <input 
                type="password" 
                value={password}
                onChange={e => setPassword(e.target.value)}
                required
                minLength={6}
                className="w-full bg-secondary border border-border rounded-lg px-4 py-3 text-sm focus:outline-none focus:ring-1 focus:ring-primary font-mono tracking-widest text-foreground"
              />
              <Lock className="w-4 h-4 text-muted-foreground absolute right-4 top-3.5 opacity-50" />
            </div>
            <p className="text-[10px] text-muted-foreground mt-2 font-mono">Any email + 6-character password creates a demo operator session.</p>
          </div>
          {error && (
            <div className="text-xs text-red-500 font-mono bg-red-500/10 border border-red-500/20 rounded-lg px-3 py-2">{error}</div>
          )}
          <div className="pt-4">
            <button 
              type="submit"
              disabled={loading}
              className="w-full bg-primary hover:bg-primary/90 disabled:opacity-60 text-primary-foreground font-bold py-3.5 rounded-lg transition-all flex items-center justify-center gap-3 text-sm tracking-widest uppercase shadow-[0_0_15px_rgba(14,165,233,0.3)] hover:shadow-[0_0_20px_rgba(14,165,233,0.5)]"
            >
              {loading ? 'AUTHENTICATING…' : 'AUTHENTICATE'} {!loading && <ChevronRight className="w-4 h-4" />}
            </button>
          </div>
        </form>

        <div className="mt-10 pt-6 border-t border-border flex flex-col items-center text-center gap-2">
          <div className="flex items-center gap-2 text-[10px] text-muted-foreground font-mono tracking-widest uppercase font-bold">
            <Lock className="w-3 h-3" />
            <span>Protected Operations Environment</span>
          </div>
        </div>
      </motion.div>
    </div>
  );
}

interface DashboardSummary {
  kpis: {
    transactionsMonitored: number; predictedFailures: number; recoverySuccess: number;
    revenueProtected: number; averageRecoveryLatencyMs: number; activeIncidents: number; providerHealth: number;
  };
}
interface PaymentHealthRow { rail: string; provider: string; status: string; successRate: number; latencyMs: number; }
interface LiveTxn { id: string; timestamp: string; provider: string; amount: number; status: string; rail: string; }
interface Incident {
  id: string; title: string; severity: string; status: string; detectedAt: string;
  affectedTransactions: number; revenueExposure: number; rootCause: string; recommendation: string;
}

function CommandCenterView({ refreshKey, onNavigate }: { refreshKey: number; onNavigate: (tab: string) => void }) {
  const summary = useApiGet<DashboardSummary>('/dashboard/summary', [refreshKey]);
  const health = useApiGet<PaymentHealthRow[]>('/dashboard/payment-health', [refreshKey]);
  const liveOps = useApiGet<LiveTxn[]>('/dashboard/live-operations?limit=8', [refreshKey]);
  const incidents = useApiGet<Incident[]>('/incidents', [refreshKey]);

  const txnCount = useAnimatedCounter(summary.data?.kpis.transactionsMonitored ?? 0, 1200);
  const failureCount = useAnimatedCounter(summary.data?.kpis.predictedFailures ?? 0, 1200);
  const revenueCount = useAnimatedCounter(summary.data?.kpis.revenueProtected ?? 0, 1200);

  const [activeModal, setActiveModal] = useState<'sim' | 'inc' | 'txn' | null>(null);
  const [activeTxnId, setActiveTxnId] = useState<string | null>(null);
  const [simResult, setSimResult] = useState<any>(null);
  const [simLoading, setSimLoading] = useState(false);
  const txnTimeline = useApiGet<any[]>(activeModal === 'txn' && activeTxnId ? `/transactions/${activeTxnId}/timeline` : null, [activeTxnId]);
  const txnDetail = useApiGet<LiveTxn & Record<string, any>>(activeModal === 'txn' && activeTxnId ? `/transactions/${activeTxnId}` : null, [activeTxnId]);

  const topIncident = incidents.data?.[0];

  const runSimulation = async () => {
    if (!topIncident) return;
    setSimLoading(true);
    try {
      const result = await api.post(`/incidents/${topIncident.id}/simulate`, { strategy: 'reroute' });
      setSimResult(result);
    } catch (e: any) {
      setSimResult({ error: e?.message || 'Simulation failed.' });
    } finally {
      setSimLoading(false);
    }
  };

  if (summary.error && !summary.data) {
    return <ErrorState message={summary.error} onRetry={summary.refresh} />;
  }

  return (
    <>
      {/* KPI SECTION */}
      {summary.loading && !summary.data ? <LoadingState label="Loading dashboard…" /> : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
          <KpiCard title="TRANSACTIONS MONITORED" value={txnCount.toLocaleString()} trend="up" trendValue="LIVE" status="neutral" />
          <KpiCard title="PREDICTED FAILURES" value={failureCount.toLocaleString()} trend="down" trendValue="AI" status="success" />
          <KpiCard title="RECOVERY SUCCESS" value={`${((summary.data?.kpis.recoverySuccess ?? 0) * 100).toFixed(1)}%`} trend="up" trendValue="24H" status="success" />
          <KpiCard title="REVENUE PROTECTED" value={formatINR(revenueCount)} trend="up" trendValue="24H" status="primary" />
          <KpiCard title="AVG RECOVERY LATENCY" value={`${summary.data?.kpis.averageRecoveryLatencyMs ?? '—'} ms`} trend="down" trendValue="p50" status="success" />
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* LIVE PAYMENT HEALTH */}
        <div className="col-span-1 border border-border rounded-xl bg-card overflow-hidden flex flex-col shadow-lg">
          <div className="p-5 border-b border-border flex items-center justify-between bg-secondary/50">
            <h2 className="text-xs font-mono font-bold tracking-widest uppercase text-foreground">LIVE PAYMENT HEALTH</h2>
          </div>
          <div className="divide-y divide-border flex-1">
            {health.loading && !health.data && <LoadingState />}
            {health.error && <ErrorState message={health.error} onRetry={health.refresh} />}
            {health.data?.map(h => (
              <HealthRow key={h.provider} name={h.rail} status={h.status} sr={`${h.successRate.toFixed(1)}%`} lat={`${h.latencyMs}ms`} />
            ))}
          </div>
        </div>

        {/* ACTIVE PAYMENT INCIDENTS */}
        <div className="col-span-2 border border-border rounded-xl bg-card overflow-hidden flex flex-col shadow-lg">
          <div className="p-5 border-b border-border flex items-center justify-between bg-secondary/50">
            <h2 className="text-xs font-mono font-bold tracking-widest uppercase text-foreground">ACTIVE PAYMENT INCIDENTS</h2>
            <button onClick={() => onNavigate('INCIDENTS')} className="text-[10px] font-mono text-primary hover:text-primary/80 uppercase tracking-widest font-bold">VIEW ALL</button>
          </div>
          <div className="p-6">
            {incidents.loading && !incidents.data && <LoadingState />}
            {incidents.error && <ErrorState message={incidents.error} onRetry={incidents.refresh} />}
            {incidents.data && incidents.data.length === 0 && <EmptyState label="No active incidents." />}
            {topIncident && (
              <div className="border border-border bg-secondary/20 rounded-lg p-5 relative overflow-hidden hover:border-red-500/50 transition-colors shadow-inner">
                <div className="absolute top-0 left-0 w-1 h-full bg-red-500 shadow-[0_0_10px_rgba(239,68,68,0.8)]" />
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <div className="text-[10px] font-mono text-muted-foreground uppercase tracking-widest mb-1 font-bold">{topIncident.id}</div>
                    <h3 className="text-sm font-semibold tracking-wide text-foreground">{topIncident.title}</h3>
                  </div>
                  <div className="px-2 py-1 bg-red-500/10 text-red-600 dark:text-red-500 border border-red-500/20 rounded text-[10px] font-mono font-bold tracking-widest">
                    SEVERITY: {topIncident.severity}
                  </div>
                </div>
                
                <div className="grid grid-cols-3 gap-4 mb-6 text-xs font-mono">
                  <div>
                    <div className="text-muted-foreground mb-1 uppercase text-[9px] font-bold">Detected</div>
                    <div className="text-foreground">{formatTime(topIncident.detectedAt)}</div>
                  </div>
                  <div>
                    <div className="text-muted-foreground mb-1 uppercase text-[9px] font-bold">Affected Txns</div>
                    <div className="text-foreground">{topIncident.affectedTransactions.toLocaleString()}</div>
                  </div>
                  <div>
                    <div className="text-muted-foreground mb-1 uppercase text-[9px] font-bold">Rev Exposure</div>
                    <div className="text-red-600 dark:text-red-400 font-bold">{formatINR(topIncident.revenueExposure)}</div>
                  </div>
                </div>

                <div className="bg-background border border-border rounded p-4 mb-6">
                  <div className="flex gap-2 items-start mb-3">
                    <BrainCircuit className="w-4 h-4 text-primary shrink-0 mt-0.5" />
                    <div>
                      <div className="text-[10px] font-mono text-primary uppercase tracking-widest mb-1 font-bold">AI Root Cause</div>
                      <div className="text-sm font-light text-foreground">{topIncident.rootCause}</div>
                    </div>
                  </div>
                  <div className="flex gap-2 items-start">
                    <Activity className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0 mt-0.5" />
                    <div>
                      <div className="text-[10px] font-mono text-emerald-600 dark:text-emerald-400 uppercase tracking-widest mb-1 font-bold">Agent Recommendation</div>
                      <div className="text-sm font-light text-foreground">{topIncident.recommendation}</div>
                    </div>
                  </div>
                </div>

                <div className="flex gap-3">
                  <button onClick={() => setActiveModal('inc')} className="px-4 py-2 border border-border hover:bg-secondary rounded text-[11px] font-mono font-bold tracking-widest uppercase transition-colors text-foreground">
                    VIEW INCIDENT
                  </button>
                  <button onClick={() => { setSimResult(null); setActiveModal('sim'); }} className="px-4 py-2 bg-primary hover:bg-primary/90 text-primary-foreground rounded text-[11px] font-mono font-bold tracking-widest uppercase transition-colors">
                    SIMULATE RECOVERY
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>

      </div>

      {/* LIVE TRANSACTIONS */}
      <div className="border border-border rounded-xl bg-card overflow-hidden flex flex-col shadow-lg mt-6">
        <div className="p-5 border-b border-border flex items-center justify-between bg-secondary/50">
          <h2 className="text-xs font-mono font-bold tracking-widest uppercase text-foreground">LIVE TRANSACTION FEED</h2>
          <div className="flex gap-2">
            <span className="flex items-center gap-2 text-[10px] font-mono text-muted-foreground uppercase tracking-widest">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
              LIVE
            </span>
          </div>
        </div>
        <div className="overflow-x-auto">
          {liveOps.loading && !liveOps.data && <LoadingState />}
          {liveOps.error && <ErrorState message={liveOps.error} onRetry={liveOps.refresh} />}
          {liveOps.data && liveOps.data.length === 0 && <EmptyState label="No transactions yet." />}
          {liveOps.data && liveOps.data.length > 0 && (
            <table className="w-full text-left">
              <thead className="bg-secondary/20 text-[10px] font-mono uppercase tracking-widest text-muted-foreground border-b border-border">
                <tr>
                  <th className="px-5 py-3 font-semibold">TIME</th>
                  <th className="px-5 py-3 font-semibold">TXN ID</th>
                  <th className="px-5 py-3 font-semibold">PROVIDER</th>
                  <th className="px-5 py-3 font-semibold">AMOUNT</th>
                  <th className="px-5 py-3 font-semibold">STATUS</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border font-mono text-xs">
                {liveOps.data.map(t => (
                  <TableRow key={t.id} onClick={() => { setActiveTxnId(t.id); setActiveModal('txn'); }} time={formatTime(t.timestamp)} tx={t.id} provider={`${t.provider} — ${t.rail}`} amount={formatINR(t.amount)} status={t.status} />
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>

      <AnimatePresence>
        {activeModal === 'inc' && topIncident && (
          <Modal onClose={() => setActiveModal(null)} title={`INCIDENT DETAILS: ${topIncident.id}`}>
            <div className="space-y-4">
              <div className="p-4 bg-red-500/10 border border-red-500/20 rounded-lg">
                <h3 className="text-red-500 font-bold mb-2">{topIncident.title}</h3>
                <p className="text-sm text-foreground/80">{topIncident.rootCause}. {topIncident.recommendation}.</p>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="p-4 bg-secondary/50 rounded-lg border border-border">
                  <div className="text-[10px] text-muted-foreground uppercase tracking-widest font-bold mb-1">Status</div>
                  <div className="font-mono text-sm">{topIncident.status}</div>
                </div>
                <div className="p-4 bg-secondary/50 rounded-lg border border-border">
                  <div className="text-[10px] text-muted-foreground uppercase tracking-widest font-bold mb-1">Revenue Exposure</div>
                  <div className="font-mono text-sm">{formatINR(topIncident.revenueExposure)}</div>
                </div>
              </div>
              <button onClick={() => onNavigate('INCIDENTS')} className="w-full py-3 bg-secondary hover:bg-secondary/80 text-foreground font-bold tracking-widest uppercase rounded transition-colors border border-border text-[11px]">
                OPEN FULL INCIDENT WORKSPACE
              </button>
            </div>
          </Modal>
        )}
        
        {activeModal === 'sim' && topIncident && (
          <Modal onClose={() => setActiveModal(null)} title="SIMULATE RECOVERY">
            <div className="space-y-6">
              <div className="text-sm text-foreground/80">
                Run a counterfactual recovery simulation for {topIncident.id}. This calls the deterministic simulation
                engine — no live transaction or routing rule is affected.
              </div>
              {!simResult && !simLoading && (
                <button onClick={runSimulation} className="w-full py-3 bg-primary hover:bg-primary/90 text-primary-foreground font-bold tracking-widest uppercase rounded transition-colors">
                  RUN SIMULATION
                </button>
              )}
              {simLoading && <LoadingState label="Running simulation…" />}
              {simResult?.error && <ErrorState message={simResult.error} onRetry={runSimulation} />}
              {simResult && !simResult.error && (
                <div className="bg-secondary/50 p-4 rounded-lg border border-border font-mono text-xs space-y-1">
                  <div className="text-primary">{`> ${simResult.safety}`}</div>
                  <div>{`> Recommended strategy: ${simResult.recommendedStrategy?.name}`}</div>
                  <div>{`> Expected recovery: ${formatINR(simResult.recommendedStrategy?.expectedRecovery)}`}</div>
                  <div>{`> Success probability: ${Math.round((simResult.recommendedStrategy?.successProbability ?? 0) * 100)}%`}</div>
                </div>
              )}
            </div>
          </Modal>
        )}

        {activeModal === 'txn' && (
          <Modal onClose={() => { setActiveModal(null); setActiveTxnId(null); }} title={`TRANSACTION DETAILS: ${activeTxnId || 'UNKNOWN'}`}>
            <div className="space-y-6">
              {txnDetail.loading && <LoadingState />}
              {txnDetail.error && <ErrorState message={txnDetail.error} />}
              {txnDetail.data && (
                <div className="grid grid-cols-2 gap-4">
                  <div className="p-4 bg-secondary/50 rounded-lg border border-border">
                    <div className="text-[10px] text-muted-foreground uppercase tracking-widest font-bold mb-1">Amount</div>
                    <div className="font-mono text-lg text-foreground">{formatINR(txnDetail.data.amount)}</div>
                  </div>
                  <div className="p-4 bg-secondary/50 rounded-lg border border-border">
                    <div className="text-[10px] text-muted-foreground uppercase tracking-widest font-bold mb-1">Provider</div>
                    <div className="font-mono text-sm text-foreground mt-1">{txnDetail.data.provider} — {txnDetail.data.rail}</div>
                  </div>
                </div>
              )}
              
              <div className="bg-secondary/20 rounded-lg border border-border p-4">
                <div className="text-[10px] font-mono text-muted-foreground uppercase tracking-widest font-bold mb-3">DECISION REPLAY</div>
                {txnTimeline.loading && <LoadingState />}
                {txnTimeline.data && txnTimeline.data.length === 0 && <EmptyState label="No replay events for this transaction." />}
                <div className="space-y-3 font-mono text-xs">
                  {txnTimeline.data?.map((ev: any, i: number) => (
                    <div key={i} className="flex gap-3 text-muted-foreground">
                      <span className="w-16 shrink-0">{formatTime(ev.timestamp)}</span>
                      <span>{ev.actor}: {ev.event}</span>
                    </div>
                  ))}
                </div>
              </div>

              <button 
                onClick={() => { setActiveModal(null); setActiveTxnId(null); }}
                className="w-full py-3 bg-secondary hover:bg-secondary/80 text-foreground font-bold tracking-widest uppercase rounded transition-colors border border-border"
              >
                CLOSE
              </button>
            </div>
          </Modal>
        )}
      </AnimatePresence>
    </>
  );
}

// --- Additional Operational Views ---

function SectionCard({ title, action, children }: { title: string; action?: React.ReactNode; children: React.ReactNode }) {
  return (
    <div className="border border-border rounded-xl bg-card overflow-hidden flex flex-col shadow-lg">
      <div className="p-5 border-b border-border flex items-center justify-between bg-secondary/50">
        <h2 className="text-xs font-mono font-bold tracking-widest uppercase text-foreground">{title}</h2>
        {action}
      </div>
      {children}
    </div>
  );
}

function Pill({ children, tone = 'neutral' }: { children: React.ReactNode; tone?: 'neutral' | 'success' | 'warning' | 'critical' | 'primary' }) {
  const map: any = {
    neutral: 'text-muted-foreground bg-secondary/50 border-border',
    success: 'text-emerald-600 dark:text-emerald-400 bg-emerald-500/10 border-emerald-500/20',
    warning: 'text-amber-600 dark:text-amber-400 bg-amber-500/10 border-amber-500/20',
    critical: 'text-red-600 dark:text-red-400 bg-red-500/10 border-red-500/20',
    primary: 'text-primary bg-primary/10 border-primary/20',
  };
  return <span className={cn('px-2 py-1 rounded text-[9px] font-bold tracking-widest uppercase border', map[tone])}>{children}</span>;
}

function severityTone(sev: string): any {
  if (sev === 'CRITICAL' || sev === 'HIGH') return 'critical';
  if (sev === 'MEDIUM') return 'warning';
  return 'success';
}

// ---- Incidents ----
function IncidentsView({ refreshKey }: { refreshKey: number }) {
  const incidents = useApiGet<Incident[]>('/incidents', [refreshKey]);
  const [selected, setSelected] = useState<string | null>(null);
  const detail = useApiGet<any>(selected ? `/incidents/${selected}` : null, [selected]);
  const [investigating, setInvestigating] = useState(false);
  const [lastInvestigatedAt, setLastInvestigatedAt] = useState<string | null>(null);

  const investigate = async () => {
    if (!selected) return;
    setInvestigating(true);
    setLastInvestigatedAt(null);
    try {
      await api.post(`/incidents/${selected}/investigate`);
      detail.refresh();
      incidents.refresh();
      setLastInvestigatedAt(new Date().toISOString());
    } finally { setInvestigating(false); }
  };

  if (incidents.loading && !incidents.data) return <LoadingState label="Loading incidents…" />;
  if (incidents.error) return <ErrorState message={incidents.error} onRetry={incidents.refresh} />;

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      <div className="lg:col-span-2 space-y-4">
        {incidents.data?.length === 0 && <EmptyState label="No incidents recorded." />}
        {incidents.data?.map(inc => (
          <div key={inc.id} onClick={() => setSelected(inc.id)} className={cn("border rounded-lg p-5 cursor-pointer transition-colors", selected === inc.id ? "border-primary/50 bg-primary/5" : "border-border bg-card hover:border-primary/30")}>
            <div className="flex justify-between items-start mb-2">
              <div>
                <div className="text-[10px] font-mono text-muted-foreground uppercase tracking-widest font-bold">{inc.id}</div>
                <h3 className="text-sm font-semibold text-foreground">{inc.title}</h3>
              </div>
              <Pill tone={severityTone(inc.severity)}>{inc.severity}</Pill>
            </div>
            <div className="flex gap-4 text-xs font-mono text-muted-foreground">
              <span>{inc.status}</span>
              <span>{inc.affectedTransactions.toLocaleString()} txns</span>
              <span className="text-red-500">{formatINR(inc.revenueExposure)}</span>
            </div>
          </div>
        ))}
      </div>
      <SectionCard title="INCIDENT WORKSPACE">
        <div className="p-5">
          {!selected && <EmptyState label="Select an incident to inspect it." />}
          {selected && detail.loading && <LoadingState />}
          {selected && detail.error && <ErrorState message={detail.error} onRetry={detail.refresh} />}
          {selected && detail.data && (
            <div className="space-y-4">
              <h3 className="text-sm font-semibold text-foreground">{detail.data.title}</h3>
              <div className="text-xs text-muted-foreground font-mono space-y-1">
                <div>Root cause: {detail.data.rootCause}</div>
                <div>AI confidence: {detail.data.aiConfidence ? `${Math.round(detail.data.aiConfidence * 100)}%` : 'Not yet investigated'}</div>
              </div>
              <div>
                <div className="text-[10px] font-mono uppercase tracking-widest text-muted-foreground font-bold mb-2">Evidence</div>
                <ul className="text-xs font-mono space-y-1 text-foreground/80 list-disc list-inside">
                  {detail.data.evidence?.map((e: string, i: number) => <li key={i}>{e}</li>)}
                </ul>
              </div>
              <div>
                <div className="text-[10px] font-mono uppercase tracking-widest text-muted-foreground font-bold mb-2">Candidate strategies</div>
                <div className="space-y-2">
                  {detail.data.strategies?.map((s: any) => (
                    <div key={s.id} className="flex justify-between text-xs font-mono bg-secondary/40 border border-border rounded px-3 py-2">
                      <span>{s.name}</span>
                      <span className="text-emerald-500">{Math.round(s.successProbability * 100)}% · {formatINR(s.expectedRecovery)}</span>
                    </div>
                  ))}
                </div>
              </div>
              <button onClick={investigate} disabled={investigating} className="w-full py-2.5 bg-primary hover:bg-primary/90 disabled:opacity-60 text-primary-foreground font-bold tracking-widest uppercase rounded transition-colors text-[11px]">
                {investigating ? 'RUNNING ROOT-CAUSE AGENT…' : 'RUN ROOT-CAUSE INVESTIGATION'}
              </button>
              {lastInvestigatedAt && !investigating && (
                <div className="flex items-center gap-2 text-[11px] font-mono text-emerald-500 justify-center pt-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                  Investigation complete at {formatTime(lastInvestigatedAt)}
                </div>
              )}
            </div>
          )}
        </div>
      </SectionCard>
    </div>
  );
}

// ---- Predictions ----
function PredictionsView({ refreshKey }: { refreshKey: number }) {
  const predictions = useApiGet<any[]>('/predictions', [refreshKey]);
  if (predictions.loading && !predictions.data) return <LoadingState label="Loading predictions…" />;
  if (predictions.error) return <ErrorState message={predictions.error} onRetry={predictions.refresh} />;
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
      {predictions.data?.length === 0 && <EmptyState label="No active predictions." />}
      {predictions.data?.map(p => (
        <div key={p.id} className="border border-border rounded-xl bg-card p-5 shadow-lg space-y-3">
          <div className="flex justify-between items-start">
            <div>
              <div className="text-[10px] font-mono text-muted-foreground uppercase tracking-widest font-bold">{p.id}</div>
              <h3 className="text-sm font-semibold text-foreground">{p.provider} · {p.rail}</h3>
            </div>
            <Pill tone={severityTone(p.risk)}>{p.risk} RISK</Pill>
          </div>
          <div className="grid grid-cols-3 gap-3 text-xs font-mono">
            <div><div className="text-muted-foreground text-[9px] uppercase font-bold mb-1">Failure prob.</div><div className="text-foreground">{Math.round(p.failureProbability * 100)}%</div></div>
            <div><div className="text-muted-foreground text-[9px] uppercase font-bold mb-1">Horizon</div><div className="text-foreground">{p.horizonMinutes}m</div></div>
            <div><div className="text-muted-foreground text-[9px] uppercase font-bold mb-1">Confidence</div><div className="text-foreground">{Math.round(p.confidence * 100)}%</div></div>
          </div>
          <div className="text-xs font-mono text-red-500">Exposure: {formatINR(p.revenueExposure)} across {p.affectedVolume.toLocaleString()} txns</div>
          <div className="flex flex-wrap gap-1.5 pt-1">
            {p.features?.map((f: string, i: number) => <span key={i} className="text-[9px] font-mono px-2 py-1 bg-secondary/50 border border-border rounded text-muted-foreground">{f}</span>)}
          </div>
        </div>
      ))}
    </div>
  );
}

// ---- Recovery Queue ----
function RecoveryQueueView({ refreshKey }: { refreshKey: number }) {
  const queue = useApiGet<any[]>('/recovery/queue', [refreshKey]);
  const [busyId, setBusyId] = useState<string | null>(null);
  const [message, setMessage] = useState<{ id: string; text: string; tone: 'success' | 'error' } | null>(null);

  const execute = async (id: string) => {
    setBusyId(id); setMessage(null);
    try {
      await api.post(`/recovery/queue/${id}/execute`);
      setMessage({ id, text: 'Executed (simulated) — recovery workflow updated.', tone: 'success' });
      queue.refresh();
    } catch (e: any) {
      setMessage({ id, text: e?.message || 'Execution requires approval first.', tone: 'error' });
    } finally { setBusyId(null); }
  };

  if (queue.loading && !queue.data) return <LoadingState label="Loading recovery queue…" />;
  if (queue.error) return <ErrorState message={queue.error} onRetry={queue.refresh} />;

  return (
    <SectionCard title="RECOVERY QUEUE" action={<Pill tone="primary">{queue.data?.length ?? 0} QUEUED</Pill>}>
      <div className="overflow-x-auto">
        {queue.data?.length === 0 && <EmptyState label="Recovery queue is empty." />}
        {queue.data && queue.data.length > 0 && (
          <table className="w-full text-left">
            <thead className="bg-secondary/20 text-[10px] font-mono uppercase tracking-widest text-muted-foreground border-b border-border">
              <tr>
                <th className="px-5 py-3">RANK</th><th className="px-5 py-3">TXN</th><th className="px-5 py-3">AMOUNT</th>
                <th className="px-5 py-3">ACTION</th><th className="px-5 py-3">RECOVERY PROB.</th><th className="px-5 py-3">STATUS</th><th className="px-5 py-3" />
              </tr>
            </thead>
            <tbody className="divide-y divide-border font-mono text-xs">
              {queue.data.map(item => (
                <tr key={item.id} className="hover:bg-black/5 dark:hover:bg-white/5">
                  <td className="px-5 py-4">#{item.rank}</td>
                  <td className="px-5 py-4">{item.transactionId}</td>
                  <td className="px-5 py-4 font-bold text-foreground">{formatINR(item.amount)}</td>
                  <td className="px-5 py-4">{item.recommendedAction}{item.requiresApproval && <span className="ml-2"><Pill tone="warning">APPROVAL</Pill></span>}</td>
                  <td className="px-5 py-4 text-emerald-500">{Math.round(item.recoveryProbability * 100)}%</td>
                  <td className="px-5 py-4"><Pill tone={item.status === 'EXECUTED_DEMO' ? 'success' : 'neutral'}>{item.status}</Pill></td>
                  <td className="px-5 py-4">
                    <button onClick={() => execute(item.id)} disabled={busyId === item.id || item.status === 'EXECUTED_DEMO'} className="px-3 py-1.5 bg-primary hover:bg-primary/90 disabled:opacity-50 text-primary-foreground rounded text-[10px] font-bold uppercase tracking-widest">
                      {busyId === item.id ? '…' : item.status === 'EXECUTED_DEMO' ? 'DONE' : 'EXECUTE'}
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
        {message && (
          <div className={cn("m-4 p-3 rounded text-xs font-mono border", message.tone === 'success' ? "bg-emerald-500/10 border-emerald-500/20 text-emerald-600 dark:text-emerald-400" : "bg-red-500/10 border-red-500/20 text-red-600 dark:text-red-400")}>
            {message.text}
          </div>
        )}
      </div>
    </SectionCard>
  );
}

// ---- Simulations ----
function SimulationsView({ refreshKey }: { refreshKey: number }) {
  const [sims, setSims] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const queue = useApiGet<any[]>('/recovery/queue', [refreshKey]);

  const runNew = async () => {
    setLoading(true); setError(null);
    try {
      const strategies = ['retry', 'reroute', 'redistribute'];
      const sim = await api.post<any>('/simulations', { strategy: strategies[sims.length % strategies.length] });
      setSims(s => [sim, ...s]);
    } catch (e: any) { setError(e?.message || 'Simulation failed.'); }
    finally { setLoading(false); }
  };

  return (
    <div className="space-y-6">
      <SectionCard title="COUNTERFACTUAL SIMULATIONS" action={
        <button onClick={runNew} disabled={loading} className="px-4 py-2 bg-primary hover:bg-primary/90 disabled:opacity-60 text-primary-foreground rounded text-[10px] font-bold uppercase tracking-widest">
          {loading ? 'RUNNING…' : 'RUN NEW SIMULATION'}
        </button>
      }>
        <div className="p-6 space-y-4">
          <p className="text-xs text-muted-foreground font-mono">Deterministic demo engine — replays candidate recovery strategies against the current recovery queue without touching live data.</p>
          {error && <ErrorState message={error} onRetry={runNew} />}
          {sims.length === 0 && !loading && <EmptyState label="No simulations run yet this session." />}
          <div className="space-y-3">
            {sims.map(sim => (
              <div key={sim.id} className="border border-border rounded-lg p-4 bg-secondary/20">
                <div className="flex justify-between items-center mb-2">
                  <span className="text-xs font-mono font-bold text-foreground">{sim.id}</span>
                  <Pill tone="success">{sim.status}</Pill>
                </div>
                <div className="text-[10px] font-mono text-primary mb-2">{sim.safety}</div>
                <div className="grid grid-cols-3 gap-3 text-xs font-mono">
                  <div><div className="text-muted-foreground text-[9px] uppercase font-bold mb-1">Strategy</div>{sim.recommendedStrategy?.name}</div>
                  <div><div className="text-muted-foreground text-[9px] uppercase font-bold mb-1">Success prob.</div>{Math.round((sim.recommendedStrategy?.successProbability ?? 0) * 100)}%</div>
                  <div><div className="text-muted-foreground text-[9px] uppercase font-bold mb-1">Expected recovery</div>{formatINR(sim.recommendedStrategy?.expectedRecovery)}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </SectionCard>
    </div>
  );
}

// ---- Providers ----
function ProvidersView({ refreshKey }: { refreshKey: number }) {
  const providers = useApiGet<any[]>('/providers', [refreshKey]);
  if (providers.loading && !providers.data) return <LoadingState label="Loading providers…" />;
  if (providers.error) return <ErrorState message={providers.error} onRetry={providers.refresh} />;
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
      {providers.data?.map(p => (
        <div key={p.id} className="border border-border rounded-xl bg-card p-5 shadow-lg space-y-3">
          <div className="flex justify-between items-start">
            <h3 className="text-sm font-semibold text-foreground">{p.name}</h3>
            <Pill tone={p.status === 'DEGRADED' ? 'warning' : 'success'}>{p.status}</Pill>
          </div>
          <div className="grid grid-cols-2 gap-3 text-xs font-mono">
            <div><div className="text-muted-foreground text-[9px] uppercase font-bold mb-1">Success rate</div>{p.successRate}%</div>
            <div><div className="text-muted-foreground text-[9px] uppercase font-bold mb-1">Latency</div>{p.latencyMs}ms</div>
            <div><div className="text-muted-foreground text-[9px] uppercase font-bold mb-1">Routing weight</div>{p.routingWeight}%</div>
            <div><div className="text-muted-foreground text-[9px] uppercase font-bold mb-1">Health score</div>{p.healthScore}</div>
          </div>
        </div>
      ))}
    </div>
  );
}

// ---- Routing ----
function RoutingView({ refreshKey }: { refreshKey: number }) {
  const routing = useApiGet<any[]>('/routing', [refreshKey]);
  const [busy, setBusy] = useState<string | null>(null);

  const act = async (id: string, action: 'approve' | 'reject') => {
    setBusy(id);
    try { await api.post(`/routing/recommendations/${id}/${action}`, action === 'reject' ? { reason: 'Rejected by operator in demo console.' } : undefined); routing.refresh(); }
    finally { setBusy(null); }
  };

  if (routing.loading && !routing.data) return <LoadingState label="Loading routing recommendations…" />;
  if (routing.error) return <ErrorState message={routing.error} onRetry={routing.refresh} />;

  return (
    <SectionCard title="ROUTING RECOMMENDATIONS">
      <div className="divide-y divide-border">
        {routing.data?.length === 0 && <EmptyState label="No routing recommendations." />}
        {routing.data?.map(r => (
          <div key={r.id} className="p-5 flex items-center justify-between gap-4">
            <div>
              <div className="text-sm font-semibold text-foreground">{r.provider}</div>
              <div className="text-xs text-muted-foreground font-mono mt-1">{r.reason}</div>
              <div className="text-xs font-mono mt-1">Weight: {r.currentWeight}% → <span className="text-primary font-bold">{r.recommendedWeight}%</span></div>
            </div>
            <div className="flex items-center gap-3 shrink-0">
              <Pill tone={r.policyStatus.includes('APPROVAL') ? 'warning' : r.policyStatus === 'APPROVED' ? 'success' : 'neutral'}>{r.policyStatus}</Pill>
              {r.policyStatus !== 'APPROVED' && r.policyStatus !== 'REJECTED' && (
                <>
                  <button disabled={busy === r.id} onClick={() => act(r.id, 'approve')} className="px-3 py-1.5 bg-primary hover:bg-primary/90 text-primary-foreground rounded text-[10px] font-bold uppercase tracking-widest disabled:opacity-50">Approve</button>
                  <button disabled={busy === r.id} onClick={() => act(r.id, 'reject')} className="px-3 py-1.5 border border-border hover:bg-secondary rounded text-[10px] font-bold uppercase tracking-widest disabled:opacity-50">Reject</button>
                </>
              )}
            </div>
          </div>
        ))}
      </div>
    </SectionCard>
  );
}

// ---- Approvals ----
function ApprovalsView({ refreshKey }: { refreshKey: number }) {
  const approvals = useApiGet<any[]>('/approvals', [refreshKey]);
  const [busy, setBusy] = useState<string | null>(null);
  const [rejectReason, setRejectReason] = useState<Record<string, string>>({});

  const approve = async (id: string) => { setBusy(id); try { await api.post(`/approvals/${id}/approve`); approvals.refresh(); } finally { setBusy(null); } };
  const reject = async (id: string) => {
    setBusy(id);
    try { await api.post(`/approvals/${id}/reject`, { reason: rejectReason[id] || 'Rejected by operator.' }); approvals.refresh(); }
    finally { setBusy(null); }
  };

  if (approvals.loading && !approvals.data) return <LoadingState label="Loading approvals…" />;
  if (approvals.error) return <ErrorState message={approvals.error} onRetry={approvals.refresh} />;

  return (
    <SectionCard title="APPROVAL QUEUE">
      <div className="divide-y divide-border">
        {approvals.data?.length === 0 && <EmptyState label="Nothing pending approval." />}
        {approvals.data?.map(a => (
          <div key={a.id} className="p-5 space-y-3">
            <div className="flex justify-between items-start gap-4">
              <div>
                <div className="text-sm font-semibold text-foreground">{a.action}</div>
                <div className="text-xs text-muted-foreground font-mono mt-1">{a.reason}</div>
                <div className="text-xs font-mono mt-1 text-foreground/80">Amount: {formatINR(a.amount)} · Confidence: {Math.round(a.confidence * 100)}%</div>
              </div>
              <Pill tone={a.status === 'PENDING' ? 'warning' : a.status === 'APPROVED' ? 'success' : 'critical'}>{a.status}</Pill>
            </div>
            {a.status === 'PENDING' && (
              <div className="flex gap-2 items-center">
                <input value={rejectReason[a.id] || ''} onChange={e => setRejectReason(r => ({ ...r, [a.id]: e.target.value }))} placeholder="Rejection reason (required to reject)" className="flex-1 bg-secondary border border-border rounded px-3 py-2 text-xs font-mono focus:outline-none focus:ring-1 focus:ring-primary" />
                <button disabled={busy === a.id} onClick={() => approve(a.id)} className="px-3 py-2 bg-primary hover:bg-primary/90 text-primary-foreground rounded text-[10px] font-bold uppercase tracking-widest disabled:opacity-50">Approve</button>
                <button disabled={busy === a.id} onClick={() => reject(a.id)} className="px-3 py-2 border border-border hover:bg-secondary rounded text-[10px] font-bold uppercase tracking-widest disabled:opacity-50">Reject</button>
              </div>
            )}
          </div>
        ))}
      </div>
    </SectionCard>
  );
}

// ---- Revenue ----
function RevenueView({ refreshKey }: { refreshKey: number }) {
  const summary = useApiGet<any>('/revenue/summary', [refreshKey]);
  const attribution = useApiGet<any[]>('/revenue/attribution', [refreshKey]);
  if (summary.loading && !summary.data) return <LoadingState label="Loading revenue data…" />;
  if (summary.error) return <ErrorState message={summary.error} onRetry={summary.refresh} />;
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <KpiCard title="REVENUE AT RISK" value={formatINR(summary.data?.revenueAtRisk)} trend="down" trendValue="24H" status="critical" />
        <KpiCard title="EXPECTED RECOVERY" value={formatINR(summary.data?.expectedRecovery)} trend="up" trendValue="MODEL" status="primary" />
        <KpiCard title="RECOVERED REVENUE" value={formatINR(summary.data?.recoveredRevenue)} trend="up" trendValue="24H" status="success" />
        <KpiCard title="ROI" value={summary.data?.roi === null ? summary.data?.dataAvailability?.roi : `${summary.data?.roi}x`} trend="up" trendValue="EST" status="neutral" />
      </div>
      <SectionCard title="REVENUE ATTRIBUTION">
        <div className="p-5 space-y-3">
          {attribution.loading && !attribution.data && <LoadingState />}
          {attribution.data?.length === 0 && <EmptyState label="No attribution data." />}
          {attribution.data?.map((a: any, i: number) => (
            <div key={i} className="flex items-center justify-between text-xs font-mono">
              <span className="text-foreground">{a.strategy || a.channel || a.name}</span>
              <span className="text-emerald-500 font-bold">{formatINR(a.recoveredRevenue || a.value)}</span>
            </div>
          ))}
        </div>
      </SectionCard>
    </div>
  );
}

// ---- Audit Log ----
function AuditLogView({ refreshKey }: { refreshKey: number }) {
  const log = useApiGet<any[]>('/audit-log?limit=200', [refreshKey]);
  if (log.loading && !log.data) return <LoadingState label="Loading audit log…" />;
  if (log.error) return <ErrorState message={log.error} onRetry={log.refresh} />;
  return (
    <SectionCard title="AUDIT & ACTIVITY LOG">
      <div className="divide-y divide-border max-h-[70vh] overflow-y-auto">
        {log.data?.length === 0 && <EmptyState label="No audit events yet." />}
        {log.data?.map((e: any, i: number) => (
          <div key={e.id || i} className="p-4 flex items-start gap-4 text-xs font-mono">
            <span className="text-muted-foreground w-32 shrink-0">{formatDateTime(e.timestamp)}</span>
            <span className="text-primary w-40 shrink-0 truncate">{e.actor}</span>
            <span className="font-bold text-foreground w-56 shrink-0 truncate">{e.action}</span>
            <span className="text-muted-foreground truncate">{e.detail}</span>
          </div>
        ))}
      </div>
    </SectionCard>
  );
}

// ---- AI Agents ----
function AgentsView({ refreshKey }: { refreshKey: number }) {
  const agents = useApiGet<any[]>('/agents', [refreshKey]);
  const activity = useApiGet<any[]>('/agents/activity?limit=30', [refreshKey]);
  if (agents.loading && !agents.data) return <LoadingState label="Loading agent fleet…" />;
  if (agents.error) return <ErrorState message={agents.error} onRetry={agents.refresh} />;
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {agents.data?.map(a => (
          <div key={a.id} className="border border-border rounded-xl bg-card p-5 shadow-lg space-y-3">
            <div className="flex justify-between items-start">
              <h3 className="text-sm font-semibold text-foreground">{a.name}</h3>
              <Pill tone="success">{a.status}</Pill>
            </div>
            <div className="text-xs text-muted-foreground font-mono">{a.currentTask}</div>
            <div className="grid grid-cols-2 gap-3 text-xs font-mono">
              <div><div className="text-muted-foreground text-[9px] uppercase font-bold mb-1">Executions</div>{a.executions}</div>
              <div><div className="text-muted-foreground text-[9px] uppercase font-bold mb-1">Success rate</div>{Math.round(a.successRate * 100)}%</div>
              <div><div className="text-muted-foreground text-[9px] uppercase font-bold mb-1">Latency</div>{a.latencyMs}ms</div>
              <div><div className="text-muted-foreground text-[9px] uppercase font-bold mb-1">Confidence</div>{Math.round(a.confidence * 100)}%</div>
            </div>
          </div>
        ))}
      </div>
      <SectionCard title="AGENT ACTIVITY STREAM">
        <div className="divide-y divide-border max-h-96 overflow-y-auto">
          {activity.data?.map((e: any) => (
            <div key={e.id} className="p-4 flex items-center gap-4 text-xs font-mono">
              <span className="text-muted-foreground w-24 shrink-0">{formatTime(e.timestamp)}</span>
              <span className="text-primary w-48 shrink-0 truncate">{e.agent}</span>
              <span className="text-foreground/80 flex-1 truncate">{e.event}</span>
              <Pill tone={e.severity === 'HIGH' ? 'critical' : e.severity === 'ACTION' ? 'primary' : 'neutral'}>{e.severity}</Pill>
            </div>
          ))}
        </div>
      </SectionCard>
    </div>
  );
}

// ---- Decision Replay ----
function DecisionReplayView({ refreshKey }: { refreshKey: number }) {
  const txns = useApiGet<LiveTxn[]>('/dashboard/live-operations?limit=15', [refreshKey]);
  const [selected, setSelected] = useState<string | null>(null);
  const replay = useApiGet<any>(selected ? `/decision-replay/${selected}` : null, [selected]);

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      <SectionCard title="SELECT A TRANSACTION">
        <div className="divide-y divide-border max-h-[60vh] overflow-y-auto">
          {txns.loading && !txns.data && <LoadingState />}
          {txns.data?.map(t => (
            <div key={t.id} onClick={() => setSelected(t.id)} className={cn("p-4 cursor-pointer text-xs font-mono flex justify-between", selected === t.id ? "bg-primary/10" : "hover:bg-black/5 dark:hover:bg-white/5")}>
              <span>{t.id}</span>
              <span className="text-muted-foreground">{t.status}</span>
            </div>
          ))}
        </div>
      </SectionCard>
      <div className="lg:col-span-2">
        <SectionCard title="AGENT DECISION REPLAY">
          <div className="p-5">
            {!selected && <EmptyState label="Pick a transaction on the left to replay its agent decision chain." />}
            {selected && replay.loading && <LoadingState />}
            {selected && replay.error && <ErrorState message={replay.error} onRetry={replay.refresh} />}
            {selected && replay.data && (Array.isArray(replay.data) ? replay.data.length === 0 : !replay.data.events?.length) && (
              <EmptyState label="No recorded decision chain for this transaction." />
            )}
            {selected && replay.data && (
              <div className="space-y-3 font-mono text-xs">
                {(Array.isArray(replay.data) ? replay.data : replay.data.events || []).map((ev: any, i: number) => (
                  <div key={i} className="flex gap-3 border-l-2 border-primary/30 pl-3 py-1">
                    <span className="text-muted-foreground w-16 shrink-0">{formatTime(ev.timestamp)}</span>
                    <div>
                      <div className="text-primary">{ev.actor}</div>
                      <div className="text-foreground/80">{ev.event}</div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </SectionCard>
      </div>
    </div>
  );
}

// ---- Settings ----
function SettingsView({ user, apiMode, onReset }: { user: AuthUser | null; apiMode: string; onReset: () => void }) {
  const [resetting, setResetting] = useState(false);
  const [resetDone, setResetDone] = useState(false);

  const resetDemo = async () => {
    setResetting(true); setResetDone(false);
    try { await api.post('/demo/reset'); setResetDone(true); onReset(); }
    finally { setResetting(false); }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      <SectionCard title="SESSION">
        <div className="p-5 space-y-2 text-sm">
          <div className="text-foreground font-semibold">{user?.name}</div>
          <div className="text-muted-foreground font-mono text-xs">{user?.email}</div>
          <div className="text-muted-foreground font-mono text-xs">Role: {user?.role}</div>
          <div className="text-muted-foreground font-mono text-xs">Backend mode: {apiMode.toUpperCase()}</div>
        </div>
      </SectionCard>
      <SectionCard title="DEMO CONTROLS">
        <div className="p-5 space-y-4">
          <p className="text-xs text-muted-foreground font-mono">Restore the seeded RecoverX demo dataset so the buildathon walkthrough can be replayed from a clean state.</p>
          <button onClick={resetDemo} disabled={resetting} className="px-4 py-2.5 bg-primary hover:bg-primary/90 disabled:opacity-60 text-primary-foreground rounded text-[11px] font-bold uppercase tracking-widest flex items-center gap-2">
            <RotateCcw className={cn("w-4 h-4", resetting && "animate-spin")} /> {resetting ? 'RESETTING…' : 'RESET DEMO DATA'}
          </button>
          {resetDone && <div className="text-xs font-mono text-emerald-500">Demo dataset restored.</div>}
        </div>
      </SectionCard>
    </div>
  );
}

// --- Shared Components ---

function Modal({ children, onClose, title }: { children: React.ReactNode, onClose: () => void, title: string }) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="absolute inset-0 bg-black/60 backdrop-blur-sm"
        onClick={onClose}
      />
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 10 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 10 }}
        className="relative w-full max-w-lg bg-background border border-border shadow-2xl rounded-xl overflow-hidden flex flex-col"
      >
        <div className="flex items-center justify-between p-4 border-b border-border bg-secondary/50">
          <h2 className="text-sm font-mono font-bold tracking-widest text-foreground uppercase">{title}</h2>
          <button onClick={onClose} className="p-1 hover:bg-black/10 dark:hover:bg-white/10 rounded-md transition-colors text-muted-foreground hover:text-foreground">
            <X className="w-4 h-4" />
          </button>
        </div>
        <div className="p-6">
          {children}
        </div>
      </motion.div>
    </div>
  );
}

function NavItem({ icon: Icon, label, active, onClick, badge, badgeColor }: { icon: any, label: string, active?: boolean, onClick?: () => void, badge?: number, badgeColor?: 'red' | 'yellow' }) {
  return (
    <button 
      onClick={onClick}
      className={cn(
        "w-full flex items-center justify-between px-4 py-2.5 rounded-lg text-xs font-medium transition-all",
        active 
          ? "bg-primary/10 text-primary border border-primary/20 shadow-[0_0_10px_rgba(var(--color-primary),0.1)] font-bold" 
          : "text-muted-foreground hover:bg-black/5 dark:hover:bg-white/5 hover:text-foreground border border-transparent font-medium"
      )}
    >
      <div className="flex items-center gap-3">
        <Icon className="w-4 h-4 shrink-0" />
        <span className="truncate tracking-wide">{label}</span>
      </div>
      {badge && (
        <span className={cn(
          "w-4 h-4 rounded-full flex items-center justify-center text-[9px] font-bold shadow-sm",
          badgeColor === 'red' ? "bg-red-500 text-white" : "bg-amber-400 text-amber-950"
        )}>
          {badge}
        </span>
      )}
    </button>
  );
}

function KpiCard({ title, value, trend, trendValue, status }: { title: string, value: string, trend: 'up'|'down', trendValue: string, status: 'success'|'warning'|'critical'|'neutral'|'primary' }) {
  const statusColors: any = {
    success: 'text-emerald-600 dark:text-emerald-400',
    warning: 'text-amber-600 dark:text-amber-400',
    critical: 'text-red-600 dark:text-red-400',
    neutral: 'text-muted-foreground',
    primary: 'text-primary'
  };

  return (
    <div className="bg-card border border-border hover:border-primary/30 rounded-xl p-5 flex flex-col gap-3 transition-colors shadow-md">
      <div className="flex justify-between items-start">
        <h3 className="text-[10px] font-mono text-muted-foreground uppercase tracking-widest font-bold">{title}</h3>
      </div>
      <div className="text-2xl font-semibold font-mono tracking-tight text-foreground">{value}</div>
      <div className="flex items-center gap-1 text-[10px] font-mono mt-auto pt-1">
        <span className={cn("flex items-center font-bold tracking-widest", statusColors[status])}>
          {trend === 'up' ? <TrendingUp className="w-3 h-3 mr-1" /> : <TrendingDown className="w-3 h-3 mr-1" />}
          {trendValue}
        </span>
        <span className="text-muted-foreground uppercase opacity-80 ml-1 font-semibold">vs prev 24h</span>
      </div>
    </div>
  );
}

function TableRow({ time, tx, provider, amount, status, onClick }: any) {
  const statusColors: any = {
    'RECOVERING': 'text-amber-500 bg-amber-500/10 border-amber-500/20',
    'FAILED': 'text-red-500 bg-red-500/10 border-red-500/20',
    'REROUTED': 'text-primary bg-primary/10 border-primary/20',
    'RECOVERED': 'text-emerald-500 bg-emerald-500/10 border-emerald-500/20',
    'BLOCKED': 'text-muted-foreground bg-secondary/50 border-border',
    'PENDING': 'text-blue-500 bg-blue-500/10 border-blue-500/20',
  };

  return (
    <tr onClick={onClick} className="hover:bg-black/5 dark:hover:bg-white/5 transition-colors cursor-pointer group">
      <td className="px-5 py-4 text-muted-foreground whitespace-nowrap">{time}</td>
      <td className="px-5 py-4 font-medium text-foreground whitespace-nowrap">{tx}</td>
      <td className="px-5 py-4 text-foreground whitespace-nowrap">{provider}</td>
      <td className="px-5 py-4 font-bold text-foreground whitespace-nowrap">{amount}</td>
      <td className="px-5 py-4 whitespace-nowrap">
        <span className={cn("px-2 py-1 rounded text-[9px] font-bold tracking-widest uppercase border", statusColors[status] || statusColors['PENDING'])}>
          {status}
        </span>
      </td>
    </tr>
  );
}

function HealthRow({ name, status, sr, lat }: any) {
  const isDegraded = status === 'DEGRADED';
  return (
    <div className="p-5 hover:bg-black/5 dark:hover:bg-white/5 transition-colors cursor-pointer group">
      <div className="flex justify-between items-center mb-4">
        <span className="font-semibold tracking-wide text-sm text-foreground">{name}</span>
        <div className="flex items-center gap-1.5 text-[10px] font-mono font-bold uppercase tracking-widest">
          <div className={cn("w-2 h-2 rounded-full", isDegraded ? "bg-amber-500 dark:bg-amber-400 animate-pulse shadow-[0_0_8px_rgba(251,191,36,0.8)]" : "bg-emerald-500 dark:bg-emerald-400")} />
          <span className={isDegraded ? "text-amber-600 dark:text-amber-400" : "text-emerald-600 dark:text-emerald-400"}>{status}</span>
        </div>
      </div>
      <div className="grid grid-cols-2 gap-4 text-xs font-mono">
        <div>
          <div className="text-muted-foreground mb-1 text-[9px] uppercase tracking-widest font-bold">Success Rate</div>
          <div className={cn("font-medium", isDegraded ? "text-amber-600 dark:text-amber-400 font-bold" : "text-foreground")}>{sr}</div>
        </div>
        <div>
          <div className="text-muted-foreground mb-1 text-[9px] uppercase tracking-widest font-bold">Latency</div>
          <div className={cn("font-medium", isDegraded ? "text-amber-600 dark:text-amber-400 font-bold" : "text-foreground")}>{lat}</div>
        </div>
      </div>
    </div>
  );
}