============================================================
                 RECOVERX — MASTER UI/UX BUILD PROMPT
============================================================

ROLE
============================================================

Act as a Principal Product Designer, Senior UX Architect,
Enterprise SaaS Designer, Fintech UX Specialist, AI Product
Designer, Design Systems Engineer, and Figma Make expert.

Build the COMPLETE RecoverX UI/UX product in Figma from scratch.

RecoverX is an AI-native payment failure recovery, payment
reliability, revenue protection, predictive monitoring, and
agentic recovery platform for real payment operations teams.

IMPORTANT:

Build the FRONTEND EXPERIENCE ONLY.

Do NOT build the backend.

Do NOT invent backend functionality.

Do NOT create fake AI claims.

Do NOT redesign this as a generic AI dashboard.

The product must feel like a serious production-grade fintech /
payment operations platform.

The backend will later provide real APIs, database data,
authentication, AI agent results, recovery actions, routing,
analytics, and WebSocket events.

Your job is to create the complete UI/UX and interactive prototype
that is ready to consume those APIs.

============================================================
                 CORE PRODUCT IDEA
============================================================

RecoverX transforms:

REACTIVE PAYMENT RETRIES

into:

PREDICTIVE
+
AGENTIC
+
REVENUE-AWARE
+
SELF-HEALING
+
HUMAN-GOVERNED
+
AUDITABLE
+
SECURE

Core lifecycle:

PAYMENT EVENT
↓
FAILURE CLASSIFICATION
↓
PREDICTION
↓
ANOMALY
↓
INCIDENT
↓
ROOT CAUSE
↓
SIMULATION
↓
RECOVERY STRATEGY
↓
RISK
↓
POLICY
↓
HUMAN APPROVAL WHEN REQUIRED
↓
RECOVERY / REROUTING
↓
OUTCOME
↓
REVENUE ATTRIBUTION
↓
LEARNING
↓
MEMORY

The UI must make this lifecycle understandable.

============================================================
                 DESIGN DIRECTION
============================================================

Create a premium enterprise fintech interface.

Visual characteristics:

- sophisticated
- minimal
- highly readable
- information-dense but not cluttered
- professional
- trustworthy
- technical
- modern
- enterprise-grade
- AI-native without looking gimmicky

Avoid:

- excessive gradients
- childish illustrations
- generic SaaS templates
- excessive rounded cards
- huge decorative AI graphics
- fake futuristic holograms
- unnecessary animations
- excessive neon
- cryptocurrency-style visuals

Use a restrained dark enterprise command-center aesthetic.

Use strong typography hierarchy.

Use consistent spacing.

Use subtle borders.

Use clear status indicators.

Use charts only where they communicate useful operational information.

============================================================
                 GLOBAL APPLICATION
============================================================

Create a persistent application shell.

LEFT SIDEBAR:

RecoverX logo

Navigation:

COMMAND CENTER
INCIDENTS
PREDICTIONS
RECOVERY QUEUE
SIMULATIONS
PROVIDERS
ROUTING
APPROVALS
REVENUE
AI AGENTS
DIGITAL TWIN
AUDIT LOG
DECISION REPLAY
SETTINGS

Bottom:

Environment indicator:
PRODUCTION / DEMO

User profile

Role

Logout

============================================================
                 COMMAND CENTER
============================================================

Create the main RecoverX operational dashboard.

Header:

RecoverX Command Center

Subtitle:

Real-time payment reliability and revenue recovery.

Top-right:

Live indicator

Environment selector

Refresh

Notifications

User profile

============================================================
                 KPI SECTION
============================================================

Show real-data-ready KPI cards.

Cards:

REVENUE AT RISK

EXPECTED RECOVERY

RECOVERED REVENUE

PROTECTED REVENUE

PAYMENTS FAILED

RECOVERY RATE

ACTIVE INCIDENTS

PROVIDER HEALTH

Each KPI must have:

value
trend
time period
status
small contextual explanation

Never use fake precision in explanatory text.

Design the values so they can later be replaced by API data.

============================================================
             LIVE PAYMENT OPERATIONS
============================================================

Create a large real-time event stream.

Title:

LIVE PAYMENT OPERATIONS

Display:

timestamp
transaction
provider
payment method
amount
status
failure category
recovery status

Example statuses:

FAILED
RECOVERING
RECOVERED
PENDING
BLOCKED
REROUTED

Use realistic sample data only as prototype data.

Clearly support an empty state.

Support loading state.

Support error state.

============================================================
             ACTIVE INCIDENTS
============================================================

Create an incident section.

Each incident card should show:

incident ID
severity
provider
payment method
failure rate
affected transactions
revenue at risk
root cause
status
created time

Statuses:

OPEN
INVESTIGATING
MITIGATING
RESOLVED

Actions:

VIEW INCIDENT
INVESTIGATE
SIMULATE
RECOVERY
VIEW REPLAY

============================================================
            PREDICTIVE ALERTS
============================================================

Create a prominent predictive section.

Example:

PREDICTIVE ALERT

Provider degradation detected.

Failure probability:
82%

Horizon:
5 minutes

Risk:
HIGH

Confidence:
88%

Show:

features contributing to prediction
provider
payment method
affected volume
revenue exposure

Actions:

INVESTIGATE
SIMULATE
VIEW DETAILS

IMPORTANT:

Do not present fabricated model accuracy.

Confidence is the model output.

Model performance metrics must only appear where actual data exists.

============================================================
                INCIDENT DETAIL
============================================================

Create a complete incident detail page.

Header:

Incident ID

Severity

Status

Provider

Payment method

Created time

Actions:

Investigate
Simulate Recovery
Start Recovery
Escalate
View Replay

Sections:

OVERVIEW

TIMELINE

FAILURE ANALYSIS

PREDICTION

ROOT CAUSE

RECOVERY STRATEGIES

RISK ANALYSIS

ROUTING

REVENUE IMPACT

AGENT ACTIVITY

AUDIT

============================================================
                  INCIDENT TIMELINE
============================================================

Create a visual lifecycle:

Payment failures detected
↓
Prediction generated
↓
Anomaly detected
↓
Incident created
↓
Root cause investigated
↓
Strategies simulated
↓
Recovery strategy selected
↓
Risk evaluated
↓
Approval requested
↓
Approval granted
↓
Routing changed
↓
Recovery executed
↓
Outcome received
↓
Revenue attributed
↓
Memory updated

Each timeline item must show:

timestamp
actor
agent/system
status
short summary

============================================================
                 INVESTIGATION VIEW
============================================================

Create an AI investigation panel.

Title:

ROOT CAUSE INVESTIGATION

Show structured findings:

LIKELY ROOT CAUSE

PROVIDER DEGRADATION

CONFIDENCE

76%

EVIDENCE

- failure rate increased
- provider latency increased
- similar historical incident detected
- payment method affected

Do not expose chain-of-thought.

Only show concise evidence summaries.

Actions:

VIEW EVIDENCE

SIMULATE

VIEW SIMILAR INCIDENTS

============================================================
              RECOVERY SIMULATION
============================================================

Create a dedicated simulation screen.

Title:

COUNTERFACTUAL RECOVERY SIMULATOR

Question:

"What happens if RecoverX chooses another strategy?"

Show strategy comparison:

RETRY
REROUTE
DELAY
ALTERNATE PROVIDER
STOP

For each:

success probability
expected recovery
risk
latency
attempt count
duplicate risk
expected value

Highlight recommended strategy.

Example:

REROUTE

Highest expected value

IMPORTANT:

Clearly label simulation results as SIMULATION.

Never imply simulation equals actual recovery.

Actions:

RUN SIMULATION
COMPARE
APPLY RECOMMENDATION

============================================================
               RECOVERY QUEUE
============================================================

Create an operational recovery queue.

Title:

RECOVERY PRIORITY

Columns:

Rank
Transaction
Amount
Failure
Provider
Recovery Probability
Expected Recovery
Risk
Priority Score
Recommended Action
Status

Filters:

Provider
Payment method
Failure type
Risk
Amount
Incident
Status

Actions:

VIEW
SIMULATE
RECOVER
ESCALATE

============================================================
                 APPROVAL CENTER
============================================================

Create human-in-the-loop approval interface.

Title:

APPROVAL CENTER

Cards/table:

Approval ID
Action
Transaction
Amount
Risk
AI recommendation
Confidence
Reason
Requested time
Requester

Actions:

APPROVE
REJECT
VIEW DETAILS

Reject must require:

rejection reason

Before approval, show:

policy requirements
risk
financial impact
duplicate risk

Make approval clearly human-controlled.

============================================================
                 PROVIDER NETWORK
============================================================

Create provider health monitoring.

Providers:

Provider A
Provider B
Provider C

Show:

health score
failure rate
latency
volume
status
prediction
routing weight

Statuses:

HEALTHY
DEGRADED
CRITICAL
RECOVERING

Create provider detail pages.

============================================================
                     ROUTING
============================================================

Create routing control interface.

Show:

CURRENT ROUTING

Provider A 70%
Provider B 20%
Provider C 10%

Show recommended routing changes.

Example:

Provider A → 20%
Provider B → 70%
Provider C → 10%

Explain:

Reason
Prediction
Risk
Policy
Approval status

Never make AI appear to directly control routing.

Show lifecycle:

AI RECOMMENDATION
↓
RISK
↓
POLICY
↓
APPROVAL
↓
EXECUTION
↓
MONITORING
↓
GRADUAL RESTORATION

Show cooldown and gradual restoration states.

============================================================
                 REVENUE INTELLIGENCE
============================================================

Create revenue analytics.

Metrics:

Revenue at risk
Expected recovery
Recovered revenue
Protected revenue
Recovery attempts
Successful recoveries
Recovery rate
Recovery cost
ROI

Clearly distinguish:

RECOVERED REVENUE

from:

PROTECTED REVENUE

Include attribution explanation.

If cost data is unavailable, display:

COST DATA UNAVAILABLE

Do not invent ROI.

============================================================
                    AI AGENTS
============================================================

Create an AI Agent Operations page.

Five agents:

1. Anomaly Detection Agent

2. Root Cause Investigation Agent

3. Recovery Strategy Agent

4. Risk & Autonomy Agent

5. Outcome & Learning Agent

For each show:

status
executions
success/failure
latency
fallback usage
last activity

Statuses:

ACTIVE
IDLE
DEGRADED
FALLBACK

Create agent detail pages.

Show:

recent executions
tool calls
decision outcome
fallback usage
errors

Never expose chain-of-thought.

============================================================
                DECISION REPLAY
============================================================

Create a powerful decision replay interface.

Title:

DECISION REPLAY

Show chronological events:

Prediction
Anomaly
Root Cause
Simulation
Strategy
Risk
Policy
Approval
Routing
Recovery
Outcome
Revenue
Learning

Each event:

timestamp
actor
agent
status
summary
related resource

Provide:

PLAY
PAUSE
STEP FORWARD
STEP BACK

This should help an operations team understand exactly what
happened without exposing internal chain-of-thought.

============================================================
                    DIGITAL TWIN
============================================================

Create a simulation environment.

Clearly label:

DIGITAL TWIN
SIMULATION ENVIRONMENT

Show:

providers
payment methods
traffic
failure rate
latency
routing weights
revenue exposure
health

Scenario controls:

Provider degradation
Provider outage
Provider recovery
Traffic spike
Latency increase
Failure spike

Actions:

RUN SCENARIO
PAUSE
RESET

Show simulation events in real time.

Never mix Digital Twin state with production state.

============================================================
                   AUDIT LOG
============================================================

Create enterprise audit interface.

Columns:

Timestamp
Actor
Role
Action
Resource
Result
Request ID

Filters:

Actor
Role
Action
Resource
Result
Date

Sensitive information must never appear.

============================================================
                 AUTHENTICATION
============================================================

Create:

LOGIN

SESSION EXPIRED

ACCESS DENIED

MFA placeholder state if required

Login screen should feel enterprise-grade.

Roles:

ADMIN
RISK_ANALYST
OPERATIONS
VIEWER

Design role-specific permission states.

Do not rely on UI hiding for security.

The backend will enforce authorization.

============================================================
                 EMPTY STATES
============================================================

Every major page must have a meaningful empty state.

Examples:

No active incidents

No pending approvals

No predictions

No recovery actions

No simulation results

No audit events

No provider incidents

Empty states must explain what the user can do next.

============================================================
                  LOADING STATES
============================================================

Create skeleton/loading states for:

dashboard
incidents
predictions
simulation
recovery queue
approvals
provider health
analytics
agent activity
audit
replay

============================================================
                    ERROR STATES
============================================================

Create realistic error states.

Examples:

Unable to load data

Connection lost

WebSocket disconnected

Authentication expired

Permission denied

Recovery action failed

Simulation failed

Provider unavailable

Include:

retry
refresh
view details

Do not expose technical stack traces.

============================================================
                REAL-TIME STATES
============================================================

Design UI behavior for WebSocket events.

Events:

payment.created
payment.failed
payment.recovered

prediction.created
prediction.alert

incident.created
incident.updated

agent.started
agent.completed

simulation.started
simulation.completed

approval.requested
approval.approved
approval.rejected

routing.change.recommended
routing.changed
routing.restored

outcome.received

revenue.updated

UI should visibly update without requiring a page refresh.

============================================================
                 INTERACTIONS
============================================================

IMPORTANT:

Make the Figma prototype genuinely interactive.

Every major button must have an interaction.

Examples:

VIEW INCIDENT
→ Incident detail

INVESTIGATE
→ Investigation panel/page

SIMULATE
→ Simulation screen

RUN SIMULATION
→ Simulation running state
→ Results state

RECOVER
→ Confirmation modal
→ Risk summary
→ Approval state if required
→ Success/failure state

APPROVE
→ Approval confirmation
→ Approved state

REJECT
→ Rejection reason modal
→ Rejected state

VIEW REPLAY
→ Decision Replay

VIEW PROVIDER
→ Provider detail

RUN DEMO
→ Demo scenario flow

VIEW ALL
→ Full incident/recovery list

Do not create dead buttons.

============================================================
                 MODALS
============================================================

Create reusable modals for:

Confirm Recovery

Simulation Results

Approval Required

Approve Action

Reject Action

Risk Warning

Routing Change

Provider Degradation

Connection Lost

Session Expired

Delete/Disable where appropriate

============================================================
                 DESIGN SYSTEM
============================================================

Create reusable Figma components.

Components:

Button
Icon Button
Badge
Status Badge
KPI Card
Table
Data Row
Chart Card
Incident Card
Prediction Card
Provider Card
Agent Card
Timeline Event
Modal
Drawer
Tabs
Dropdown
Filter
Search
Toast
Tooltip
Empty State
Loading Skeleton
Error State

Use variants for:

default
hover
active
disabled
loading
success
warning
danger

============================================================
                 RESPONSIVENESS
============================================================

Design for:

Desktop
Laptop
Tablet

Primary experience:

1440px desktop.

Maintain proper spacing and hierarchy.

Do not allow important operational information to disappear on
smaller screens.

============================================================
                SAMPLE DATA RULE
============================================================

Use sample data ONLY for prototype visualization.

Clearly structure the design so sample values can later be replaced
by API responses.

Do not claim sample numbers are real.

Do not use fake model accuracy.

Do not use fake recovery revenue.

Do not imply a transaction was actually recovered unless the UI
state explicitly represents a prototype/demo scenario.

============================================================
             FRONTEND/BACKEND CONTRACT
============================================================

Design screens around these backend resources:

/auth/login

/live/summary

/incidents

/incidents/{id}

/incidents/{id}/replay

/predictions

/recovery/priority

/recovery

/routing/state

/approvals/pending

/approvals/{id}/approve

/approvals/{id}/reject

/simulate/recovery

/simulate/recovery/{id}

/analytics/overview

/analytics/recovery

/analytics/providers

/analytics/revenue

/analytics/agents

/analytics/predictions

/analytics/routing

/audit

/demo/scenario/provider-degradation

/ws/live

The UI should be structured so these API responses can be mapped
cleanly into components.

============================================================
                 FINAL DELIVERABLE
============================================================

Produce a COMPLETE RecoverX enterprise UI/UX system.

Required screens:

1. Login
2. Command Center
3. Incidents
4. Incident Detail
5. Investigation
6. Predictions
7. Recovery Queue
8. Recovery Detail
9. Counterfactual Simulation
10. Approval Center
11. Provider Network
12. Provider Detail
13. Routing
14. Revenue Intelligence
15. AI Agents
16. Agent Detail
17. Digital Twin
18. Decision Replay
19. Audit Log
20. Settings
21. Error States
22. Empty States
23. Loading States
24. Permission Denied
25. Session Expired

Create all necessary components and variants.

Create realistic prototype interactions between screens.

Ensure navigation is consistent.

Ensure there are no dead-end screens.

Ensure every major CTA has a meaningful interaction.

============================================================
                 MOST IMPORTANT RULE
============================================================

DO NOT MAKE THIS LOOK LIKE A DESIGN MOCKUP.

Make it feel like a real payment operations platform.

The person using RecoverX should immediately understand:

WHAT IS FAILING?

WHY IS IT FAILING?

WHAT WILL HAPPEN NEXT?

HOW MUCH REVENUE IS AT RISK?

WHAT DOES AI RECOMMEND?

WHAT IS THE RISK?

DOES A HUMAN NEED TO APPROVE?

WHAT ACTION WILL BE TAKEN?

WHAT ACTUALLY HAPPENED?

HOW MUCH REVENUE WAS RECOVERED?

WHAT DID THE SYSTEM LEARN?

Everything must communicate:

TRUST
CONTROL
VISIBILITY
SAFETY
INTELLIGENCE
RELIABILITY

Build the entire RecoverX UI/UX now.
============================================================# RECOVERX — SETTINGS UI/UX UPGRADE ADD-ON

IMPORTANT:

Do NOT replace the existing Settings page blindly.

First preserve the existing RecoverX Settings visual language,
layout, typography, navigation, components, and interaction style.

UPGRADE the existing Settings experience so it properly represents
the finalized RecoverX backend.

Do not create unnecessary settings.

Settings must feel like an enterprise fintech administration
console.

============================================================

1. SETTINGS STRUCTURE
   ============================================================

Organize Settings into clear sections:

ACCOUNT

* Profile
* Role
* Preferences
* Notifications
* Session / Security

WORKSPACE

* Workspace details
* Environment
* Regional preferences
* Data preferences

AI & AUTONOMY

* AI Agents
* Autonomy Controls
* AI Action Permissions
* Human Approval Requirements

RISK & POLICY

* Risk Controls
* Recovery Policies
* Retry Policies
* Routing Policies
* Financial Limits
* Duplicate Protection
* Cooldown Rules

PAYMENTS & PROVIDERS

* Payment Providers
* Provider Configuration
* Routing Configuration
* Payment Methods

INTEGRATIONS

* API / Integration settings
* Webhook configuration
* Event configuration
* Real-time connection settings

NOTIFICATIONS

* Incident alerts
* Prediction alerts
* Recovery alerts
* Approval requests
* Provider alerts
* Agent alerts
* System alerts

AUDIT & GOVERNANCE

* Audit configuration
* Decision Replay settings
* Data retention
* Access history

SYSTEM

* System status
* Environment
* Feature availability
* Maintenance information

============================================================
2. AI & AUTONOMY SETTINGS
=========================

Create an AI & Autonomy settings page.

Show each RecoverX agent:

Anomaly Detection Agent
Root Cause Investigation Agent
Recovery Strategy Agent
Risk & Autonomy Agent
Outcome & Learning Agent

For each show:

Status
Enabled / Disabled
Current autonomy level
Allowed actions
Restricted actions
Fallback behavior

Autonomy levels:

OBSERVE ONLY
RECOMMEND
AUTO — LOW RISK
AUTO — POLICY CONTROLLED
APPROVAL REQUIRED
HUMAN ONLY

Changing autonomy must require appropriate permission.

For sensitive changes:

SHOW CONFIRMATION

Example:

"Changing this setting may allow RecoverX to execute recovery
actions automatically."

Require confirmation before applying.

============================================================
3. POLICY SETTINGS
==================

Create a Policy configuration interface.

Policies include:

Maximum retry attempts
Maximum recovery amount
Duplicate payment protection
Provider restrictions
Routing restrictions
Autonomous action limits
Approval requirements
Cooldown periods
Recovery frequency limits

Each policy should show:

Policy name
Status
Current value
Scope
Last modified
Modified by

Actions:

EDIT
VIEW HISTORY
DISABLE where permitted

Sensitive policy changes should require confirmation.

============================================================
4. RISK SETTINGS
================

Create Risk Controls.

Show configurable thresholds such as:

Financial risk threshold
Duplicate risk threshold
Provider risk threshold
Operational risk threshold
Autonomy threshold

Display:

CURRENT VALUE
DEFAULT
IMPACT

When changing a threshold, show:

"What changes if you increase/decrease this?"

Do not pretend frontend values enforce security.
Backend remains authoritative.

============================================================
5. HUMAN APPROVAL SETTINGS
==========================

Create Approval Rules.

Allow authorized administrators to configure
which actions require human approval.

Examples:

Large recovery
High-risk recovery
Provider rerouting
Multiple retries
Unusual payment behavior
Policy exceptions

Display:

ACTION
→
RISK
→
POLICY
→
APPROVAL REQUIREMENT

Make governance visually obvious.

============================================================
6. PROVIDER SETTINGS
====================

Create provider configuration.

For each provider show:

Provider name
Status
Connection
Health
Routing eligibility
Current routing weight
Fallback status

Allow authorized users to configure only supported settings.

Dangerous actions must require confirmation.

Never imply that UI configuration alone changes production
behavior without backend confirmation.

============================================================
7. NOTIFICATION SETTINGS
========================

Create a professional notification center.

Categories:

Incidents
Predictions
Recovery
Approvals
Providers
AI Agents
System
Security

For each:

In-app
Email
Push where supported

Controls:

ON
OFF

Allow severity-based preferences:

CRITICAL
HIGH
MEDIUM
LOW

============================================================
8. SECURITY SETTINGS
====================

Create:

Password / authentication
Session management
MFA state
Active sessions
Login history
Access history

Show:

Current session
Other active sessions
Last login

Provide:

SIGN OUT OTHER SESSIONS

if supported.

Sensitive security actions require confirmation.

============================================================
9. ROLE & PERMISSIONS
=====================

Create an Admin-only permission view.

Roles:

ADMIN
RISK_ANALYST
OPERATIONS
VIEWER

Show a permission matrix:

View
Investigate
Simulate
Recover
Approve
Change Routing
Modify Policy
Change Autonomy
View Audit
View Decision Replay
Manage Providers
Manage Users

Clearly show:

ALLOWED
RESTRICTED
ADMIN ONLY

Do not imply that frontend visibility is security enforcement.

Backend authorization remains the source of truth.

============================================================
10. ENVIRONMENT SETTINGS
========================

Make environment state extremely clear.

Supported:

PRODUCTION
DEMO
DIGITAL TWIN

Production:

PRODUCTION
REAL ACTIONS MAY AFFECT LIVE PAYMENT OPERATIONS

Demo:

DEMO
SIMULATED DATA

Digital Twin:

DIGITAL TWIN
NO PRODUCTION IMPACT

Never allow the interface to visually confuse these environments.

============================================================
11. API / INTEGRATION SETTINGS
==============================

Create an enterprise integration section.

Show:

Integration name
Status
Connection
Last successful event
Last error
Webhook status

Provide supported actions such as:

CONNECT
DISCONNECT
TEST CONNECTION
VIEW EVENTS

Never display sensitive credentials in plain text.

Secrets should appear masked.

============================================================
12. DATA & RETENTION
====================

Create data governance settings.

Show:

Audit retention
Decision Replay retention
Event retention
Learning/memory retention

Show current policy and last modification.

Do not claim compliance certifications unless backed by actual
system data.

============================================================
13. SETTINGS CHANGE HISTORY
===========================

Every important configuration change should be traceable.

Show:

Timestamp
Actor
Setting
Previous value
New value
Reason
Request ID

Provide:

VIEW AUDIT
VIEW DECISION REPLAY

where applicable.

============================================================
14. DANGEROUS ACTION UX
=======================

For sensitive actions:

Disable autonomous recovery
Change recovery limits
Change routing rules
Change provider configuration
Modify policy
Disable protection
Change autonomy

Use:

WARNING
→
IMPACT
→
CONFIRMATION
→
BACKEND RESULT

Never use a single-click destructive action.

============================================================
15. SETTINGS STATES
===================

Every setting must support:

LOADING
SAVED
UNSAVED CHANGES
SAVING
SUCCESS
FAILED
RESTRICTED
POLICY BLOCKED

Show clear feedback.

Example:

"Changes saved successfully."

"Unable to save changes."

"This setting is controlled by policy."

"You do not have permission to modify this setting."

============================================================
16. REAL-TIME SETTINGS FEEDBACK
===============================

When configuration changes are confirmed by the backend:

update the UI immediately.

Show:

CHANGE REQUESTED
→
PROCESSING
→
CONFIRMED

If backend confirmation fails:

CHANGE FAILED

Do not show a setting as successfully changed before backend
confirmation.

============================================================
17. SETTINGS SEARCH
===================

Add settings search.

Example:

Search settings...

Searching:

"retry"

should surface:

Retry limit
Recovery policy
Approval rule
Related risk control

This should feel like a modern enterprise settings console.

============================================================
18. SETTINGS UX QUALITY
=======================

Maintain the existing RecoverX design system.

Use:

clear sections
strong hierarchy
compact controls
descriptive labels
tooltips
inline explanations
confirmation dialogs
success/error feedback

Avoid:

overly complicated forms
unnecessary settings
developer jargon
hidden critical controls

============================================================
19. FINAL SETTINGS EXPERIENCE
=============================

The Settings area should answer:

WHO AM I?

WHAT CAN I DO?

WHAT CAN RECOVERX DO AUTOMATICALLY?

WHAT REQUIRES MY APPROVAL?

WHAT POLICIES CONTROL AI?

WHAT RISK LIMITS EXIST?

WHICH PROVIDERS ARE CONFIGURED?

WHAT NOTIFICATIONS WILL I RECEIVE?

WHAT ENVIRONMENT AM I IN?

WHO CHANGED A SETTING?

WHAT CHANGED?

WHEN DID IT CHANGE?

WAS THE CHANGE CONFIRMED?

============================================================
20. PRESERVATION RULE
=====================

DO NOT completely redesign the existing Settings page.

PRESERVE the existing RecoverX Settings experience.

UPGRADE it with:

AI controls
Autonomy
Risk
Policy
Approvals
Providers
Integrations
Security
Permissions
Notifications
Environment
Auditability
Change history

The final Settings experience must feel like the natural
administration layer of the same RecoverX product.

It must match the sealed backend without becoming unnecessarily
complex.

============================================================
FINAL RULE

SETTINGS SHOULD CONTROL THE PRODUCT.

THE BACKEND SHOULD ENFORCE THE CONTROL.

THE UI SHOULD MAKE THE CONTROL,
RISK,
AUTHORITY,
AND RESULT# RECOVERX — FINAL UI/UX UPGRADE ADD-ON

## SEALED BACKEND + WELCOME EXPERIENCE + SUPPORT + PRODUCTION-GRADE MOTION

IMPORTANT:

THIS IS AN ADDITION TO THE EXISTING RECOVERX UI/UX SPECIFICATION.

DO NOT REPLACE THE EXISTING UI.

DO NOT REMOVE EXISTING SCREENS.

DO NOT REBUILD THE PRODUCT FROM SCRATCH.

PRESERVE THE EXISTING:

* visual design
* navigation
* pages
* components
* layouts
* typography
* color system
* existing interactions
* existing prototype flows
* existing design language

UPGRADE the existing RecoverX experience to match the finalized backend and make the product feel like a REAL production-grade enterprise fintech platform suitable for presentation to companies such as Razorpay.

The result must feel like the SAME RecoverX product, simply more complete, polished, intelligent, interactive, animated, and production-ready.

============================================================

1. KEEP ALL PREVIOUS SEALED UI UPGRADES
   ============================================================

Retain all previously specified upgrades:

* AI Agent Orchestration
* Risk & Autonomy
* Policy Governance
* Recovery Optimization
* Digital Twin
* Memory & Continuous Learning
* Decision Replay
* Revenue Attribution
* Human-in-the-Loop
* Real-Time Events
* Loading / Empty / Error / Stale states
* Security / Permissions
* Demo Mode
* Complete RecoverX lifecycle

Do not remove or simplify these capabilities.

============================================================
2. ADD A PREMIUM RECOVERX WELCOME / LANDING EXPERIENCE
======================================================

Add a polished public-facing RecoverX welcome experience BEFORE
the authenticated application.

This must NOT look like a generic startup landing page.

It should feel like the entry point to a serious enterprise fintech
platform.

Hero:

RECOVERX

AI-NATIVE PAYMENT RELIABILITY
AND REVENUE RECOVERY

Supporting message:

"Predict failures. Recover revenue. Protect every payment."

Show a concise explanation of what RecoverX does.

Explain the platform using clear product language:

* Predict payment failures before they escalate
* Investigate root causes automatically
* Simulate recovery strategies
* Optimize recovery decisions
* Apply risk and policy controls
* Keep humans in control of sensitive decisions
* Recover and protect revenue
* Learn continuously from outcomes
* Replay every important decision

Primary CTA:

ENTER RECOVERX

Secondary CTA:

EXPLORE HOW IT WORKS

Additional CTA:

RUN INTERACTIVE DEMO

============================================================
3. MAKE THE WELCOME PAGE INTERACTIVE
====================================

Do not make the welcome page a static hero.

Create interactive product storytelling.

Example interactive lifecycle:

PAYMENT
→
DETECT
→
PREDICT
→
INVESTIGATE
→
SIMULATE
→
OPTIMIZE
→
RECOVER
→
LEARN

When the user interacts with each stage, reveal a concise
explanation and a small visual representation of the capability.

Example:

PREDICT

"RecoverX detects emerging payment degradation before it becomes
a major incident."

INVESTIGATE

"AI agents analyze payment, provider, and historical signals."

SIMULATE

"Test recovery strategies without affecting production."

RECOVER

"Execute governed recovery actions with human approval when
required."

LEARN

"Use outcomes to improve future recovery decisions."

Keep the interactions subtle and professional.

============================================================
4. ADD "HOW RECOVERX WORKS"
===========================

Create an interactive section explaining the complete platform.

Visual flow:

PAYMENT EVENT
↓
AI DETECTION
↓
PREDICTION
↓
ROOT CAUSE
↓
RECOVERY STRATEGY
↓
DIGITAL TWIN
↓
RISK
↓
POLICY
↓
APPROVAL
↓
RECOVERY
↓
OUTCOME
↓
REVENUE
↓
LEARNING

Each stage should be clickable.

Selecting a stage should reveal:

What happens
Why it matters
What RecoverX produces

Do not expose technical implementation details unnecessarily.

============================================================
5. ADD PRODUCT CAPABILITY SECTION
=================================

Create an interactive capability showcase.

Cards:

PREDICTIVE MONITORING

AI AGENTS

RECOVERY OPTIMIZATION

DIGITAL TWIN

RISK ENGINE

POLICY GOVERNANCE

HUMAN APPROVAL

REVENUE INTELLIGENCE

MEMORY & LEARNING

DECISION REPLAY

AUDITABILITY

Each card should have:

icon
short explanation
interactive hover state
subtle motion
"Explore" interaction

Clicking should take the user to the relevant authenticated
product screen or demo state.

============================================================
6. ADD "BUILT FOR PAYMENT OPERATIONS"
=====================================

Create a section communicating the real-world operational value.

Show use cases:

PAYMENT FAILURE

PROVIDER DEGRADATION

PROVIDER OUTAGE

PAYMENT RETRY OPTIMIZATION

SMART ROUTING

REVENUE PROTECTION

RISK GOVERNANCE

INCIDENT RESPONSE

Use realistic enterprise terminology.

Do NOT make unsupported claims such as:

"99.99% recovery"

"guaranteed revenue"

"100% autonomous"

or fabricated performance statistics.

============================================================
7. ADD SUPPORT / HELP EXPERIENCE
================================

Add a dedicated Support / Help experience.

This should be accessible from:

Welcome page
Application shell
User profile/help icon

Create:

HELP CENTER

Sections:

Getting Started
Using Command Center
Understanding Incidents
Understanding Predictions
Recovery Operations
AI Agents
Digital Twin
Risk & Policy
Approvals
Routing
Revenue Attribution
Decision Replay
Audit Logs
Account & Permissions

Add:

Search Help

FAQ

Contact Support

Report an Issue

System Status

Documentation

============================================================
8. ADD INTERACTIVE SUPPORT PANEL
================================

Create a support drawer/panel rather than forcing users to leave
the product.

Example:

Need help?

Search documentation

Common actions:

How does recovery work?
Why does an action require approval?
What does "Protected Revenue" mean?
How does Digital Twin differ from Production?
How can I replay a decision?

Each answer should open inside the product.

============================================================
9. ADD PRODUCT STATUS EXPERIENCE
================================

Create a System Status page/panel.

Show:

RecoverX Core
Payment Monitoring
Prediction Engine
AI Agents
Recovery Engine
Risk Engine
Policy Engine
Digital Twin
WebSocket
Analytics

Statuses:

OPERATIONAL
DEGRADED
OUTAGE
MAINTENANCE

Use realistic status visualization.

Do not fabricate real uptime percentages.

If live status data is unavailable:

STATUS DATA UNAVAILABLE

============================================================
10. ADD GLOBAL SEARCH
=====================

Add a professional enterprise search experience.

Search across:

Incidents
Transactions
Predictions
Recovery Actions
Providers
Agents
Approvals
Decision Replays
Audit Events
Memory

Show:

search input
recent searches
filters
categorized results

Keyboard shortcut:

/

or

CTRL + K

Use a command-palette style interaction.

============================================================
11. ADD COMMAND PALETTE
=======================

Create a powerful command palette.

Example commands:

Go to Command Center
View Incidents
Open Recovery Queue
Open Approvals
Run Simulation
View Providers
Open AI Agents
Open Digital Twin
Open Decision Replay
View Revenue
Open Audit Log
Open Settings

Respect user permissions.

Restricted actions must display:

ACTION RESTRICTED

============================================================
12. PRODUCTION-GRADE ANIMATION
==============================

Add animation throughout the product.

IMPORTANT:

Animations must make RecoverX feel alive and operational,
not like a flashy concept demo.

Use subtle professional motion for:

* page transitions
* sidebar transitions
* live event updates
* KPI updates
* incident creation
* prediction alerts
* agent activity
* agent handoffs
* simulation progress
* recovery progress
* approval transitions
* routing changes
* provider state changes
* revenue updates
* decision replay
* notifications
* modal/drawer transitions

Use:

fade
slide
scale
progress animation
number transitions
status transitions
micro-interactions

Avoid:

excessive bouncing
large cinematic animations
random floating objects
neon effects
gaming-style motion
unnecessary particle effects

============================================================
13. AI AGENT ANIMATION
======================

Make the AI Agent experience visually communicate activity.

When an agent is active:

show subtle activity indicator.

When agents hand off:

Agent A
→
HANDOFF
→
Agent B

Animate the handoff subtly.

When an agent completes:

ACTIVE
→
COMPLETED

When fallback occurs:

ACTIVE
→
FALLBACK

When an agent fails:

ACTIVE
→
ERROR

Do not animate fake activity when no real event exists.

============================================================
14. LIVE PAYMENT ANIMATION
==========================

In Command Center, make the payment stream feel live.

New events should enter the stream smoothly.

Status transitions:

FAILED
→
RECOVERING
→
RECOVERED

or:

FAILED
→
BLOCKED

Use subtle row highlighting and status transitions.

Never imply real transactions in production when the UI is using
demo data.

============================================================
15. INCIDENT ANIMATION
======================

When a new incident is detected:

show:

PREDICTION
→
ANOMALY
→
INCIDENT CREATED

Use a subtle notification and timeline animation.

Critical incidents may use stronger visual emphasis,
but never flashing or distracting effects.

============================================================
16. SIMULATION ANIMATION
========================

Digital Twin / Recovery Simulation should visually show progress.

Example:

INITIAL STATE
→
SCENARIO APPLIED
→
SYSTEM RESPONSE
→
STRATEGY EVALUATION
→
SIMULATION RESULT

Display progress while simulation is running.

Clearly label:

SIMULATION

Never confuse it with production execution.

============================================================
17. RECOVERY ANIMATION
======================

When an actual recovery action is initiated:

CONFIRMATION
→
RISK CHECK
→
POLICY CHECK
→
APPROVAL
→
EXECUTION
→
VERIFICATION
→
OUTCOME

Animate these states sequentially.

Do not skip governance steps visually.

============================================================
18. DECISION REPLAY ANIMATION
=============================

Make Decision Replay feel like an actual operational replay.

Timeline should progressively reveal:

Payment
Prediction
Incident
Investigation
Simulation
Strategy
Risk
Policy
Approval
Routing
Recovery
Outcome
Revenue
Learning

PLAY should move through the timeline.

PAUSE stops it.

STEP FORWARD moves one event.

STEP BACK returns one event.

The interface should clearly indicate the current point in time.

============================================================
19. REAL-WORLD PRODUCT POLISH
=============================

Make the application feel like a product that could actually be
used daily by a payment operations team.

Add:

* realistic hover states
* focus states
* keyboard navigation
* tooltips
* contextual help
* toast notifications
* confirmation dialogs
* breadcrumbs
* filters
* sorting
* pagination
* search
* date selectors
* environment indicators
* data freshness indicators
* last updated timestamps
* connection indicators
* permission indicators

Avoid unnecessary decoration.

============================================================
20. MICROCOPY
=============

Use professional enterprise microcopy.

Examples:

"Provider degradation detected."

"Recovery strategy requires approval."

"Simulation completed."

"Policy prevented autonomous execution."

"Recovery action verified."

"Revenue attribution pending."

"Waiting for outcome."

"Connection restored."

"Decision replay available."

"Production action blocked by policy."

Avoid generic text such as:

"Oops!"

"Something magical happened!"

"AI is thinking..."

Use operational language.

============================================================
21. RAZORPAY-LEVEL PRODUCT QUALITY
==================================

The visual quality should be comparable to a serious enterprise
fintech product.

Take inspiration from the QUALITY BAR of mature fintech products:

* clarity
* hierarchy
* information density
* trust
* speed
* operational usefulness
* polished interactions
* strong typography
* disciplined spacing
* excellent data visualization
* clear system states

Do NOT copy Razorpay branding, logo, colors, or proprietary UI.

RecoverX must have its own identity.

The goal is:

"Could this realistically be shown to a fintech company
without looking like a student project?"

The answer must be YES.

============================================================
22. RESPONSIVE AND ACCESSIBLE
=============================

Preserve existing responsive layouts.

Ensure:

desktop
laptop
tablet

remain usable.

Add:

keyboard navigation
visible focus states
accessible labels
sufficient contrast
clear status indicators
reduced-motion-friendly behavior

Animations must not prevent users from understanding the interface.

============================================================
23. DATA HONESTY
================

This rule is mandatory.

Never fabricate:

financial results
recovery rates
model accuracy
ROI
system uptime
provider performance
production transactions
AI success rates

Prototype data must be clearly identified.

Use:

DEMO DATA

when appropriate.

Use:

DATA UNAVAILABLE

when actual data is not available.

Use:

SIMULATION

for simulated results.

Use:

MODEL OUTPUT

for predictions.

Use:

ACTUAL RESULT

only when backend-confirmed.

============================================================
24. FINAL EXPERIENCE
====================

The user journey should now feel like:

WELCOME
↓
UNDERSTAND RECOVERX
↓
EXPLORE HOW IT WORKS
↓
RUN DEMO
↓
ENTER COMMAND CENTER
↓
MONITOR PAYMENTS
↓
SEE PREDICTION
↓
INVESTIGATE INCIDENT
↓
COMPARE RECOVERY STRATEGIES
↓
SIMULATE
↓
ASSESS RISK
↓
CHECK POLICY
↓
APPROVE IF REQUIRED
↓
RECOVER
↓
VERIFY OUTCOME
↓
ATTRIBUTE REVENUE
↓
LEARN
↓
REPLAY DECISION
↓
AUDIT

============================================================
25. FINAL PRESERVATION RULE
===========================

DO NOT replace the existing RecoverX UI.

DO NOT start over.

DO NOT redesign the entire product.

DO NOT remove existing screens.

DO NOT change the established design system unnecessarily.

DO NOT create random new dashboards.

Instead:

PRESERVE
+
EXTEND
+
POLISH
+
ANIMATE
+
CONNECT

Add the missing sealed-backend capabilities.

Add the welcome experience.

Add support.

Add system status.

Add global search and command palette.

Add production-grade animations.

Add real-world interaction states.

Add professional microcopy.

Add the complete agentic lifecycle.

Add strong production/demo separation.

The final RecoverX experience should feel:

REAL
FAST
INTELLIGENT
SAFE
TRUSTWORTHY
OPERATIONAL
PREMIUM
ENTERPRISE-READY

MOST IMPORTANT:

KEEP THE EXISTING RECOVERX UI.

UPGRADE IT.

MAKE IT FEEL ALIVE.

MAKE IT FEEL LIKE A REAL FINTECH PRODUCT.

MAKE EVERY INTERACTION MEANINGFUL.

MAKE THE COMPLETE SEALED BACKEND VISIBLE THROUGH THE UI.

# DO NOT REPLACE THE EXISTING PRODUCT.

CLEAR TO THE USER.
==================
